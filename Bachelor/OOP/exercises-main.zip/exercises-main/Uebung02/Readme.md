# Übung 2: Spiel des Lebens

- [Hilfestellungen](#hilfestellungen)

## Kernthemen

- Wiederholung der prozeduralen Programmierung

## Spielaufbau

Bevor wir mit der objektorientierten Programmierung durchstarten, üben wir nochmals prozedurale
Programmierung in Java. Ihre Aufgabe besteht darin, Conways Spiel des Lebens in Java zu
implementieren und zu simulieren.

Die Übung setzt eine Matrix der Dimension 10 x 10 voraus,
siehe folgende Abbildung.
![Matrix](Hilfestellungen/matrix.png)

Zu Beginn (1. Generation) ist jede
Zelle mit einer Wahrscheinlichkeit von 50% tot bzw. lebendig.
Tote Zellen werden durch „0“ bezeichnet, lebendige Zellen
durch ein „X“. Aus der n. Generation berechnet man die
Nachfahrengeneration n+1 anhand von 4 festen Regeln:

- Lebende Zellen mit weniger als 2 lebenden Nachbarn
  sterben in der Folgegeneration an Einsamkeit.
- Lebende Zellen mit mehr als 3 lebenden Nachbarn
  sterben in der Folgegeneration an Überbevölkerung.
- Lebende Zellen mit 2 oder 3 lebenden Nachbarn bleibt
  in der Folgegeneration am Leben.
- Eine tote Zelle mit genau 3 lebenden Nachbarn wird
  in der nächsten Generation neugeboren.
  

  Ausgehend von einer Anfangsgeneration kann man iterativ die Folgegenerationen
  berechnen. Jede Zelle ist dabei von genau 8 Nachbarn umgeben. Die folgende Abbildung
  zeigt die 8 (grünen) Nachbarn der roten Zelle. Eine Ausnahme bilden Zellen am linken,
  rechten, oberen oder unteren Rand.

![Zellen rundherum](Hilfestellungen/umfeld.png)

Man kann sich mit dem Modell des „Spiel des Lebens“ aus verschiedenen Sichtweisen beschäftigen,
z.B. unter biologischen Aspekten (Mikrokosmos) oder unter ökonomischen Aspekten (Modell des
Computerhandels bei Finanzmärkten). Eine genauere Beschreibung dieses „Spiels“ sowie dessen
Anwendungen finden Sie in der Wikipedia:
- https://de.wikipedia.org/wiki/Conways_Spiel_des_Lebens  

Verwenden Sie das in der Community vorgegebene Programmgerüst.

## Schritt 1: Initialisierung

Initialisieren Sie zu Beginn der main-Methode das vorgegebene 2-dimensionale Array cells. Es soll
gewürfelt werden, ob eine Zelle tot oder lebendig ist. Die Wahrscheinlichkeit für eine tote Zelle sei 0,5.

Hinweise: Ggfs. Internetrecherche wie man ein 2-dimensionales Array in Java einsetzt. Verwenden Sie
den Aufruf Math.random(), der eine double Zufallszahl aus dem Bereich [0;1[ zurückliefert:
https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#random--

## Schritt 2
````java
private static void printCells(boolean[][] c)
````
Implementieren Sie eine Methode, die als Parameter ein 2-dimensionales Array c bekommt und auf der
Konsole die aktuelle Belegung des Arrays in ähnlicher Form ausgibt wie in der ersten Abbildung (X:
Lebende Zelle, O: tote Zelle).

## Schritt 3
````java
 private static int countLivingNeighbors(boolean[][] c, int x, int y)
````
Implementieren Sie eine Methode, die zählt wie viele lebende Nachbarn eine bestimmte Zelle c[x][y]
hat. Berücksichtigen Sie dabei die Sonderfälle an den Ecken bzw. Rändern des Feldes.


## Schritt 4: Berechnung der Nachfolgegeneration
````java
private static boolean[][] computeNextGenCells(boolean[][] cells)
````
Implementieren Sie eine Methode, die unter Beachtung der 4 Regeln, die Nachfolgegeneration
berechnet und als 2-dimensionales Array zurückliefert.

Lassen Sie Ihr Programm laufen, setzen Sie ggfs. Debugging ein!
Beobachten Sie ob sich bei verschiedenen Ausgangskonfigurationen ggfs. typische Objektmuster
ergeben, z.B. Objekte die ganz verschwinden, die unverändert bleiben, die sich periodisch verändern
oder ob vielleicht sogar die Population komplett ausstirbt. (siehe auch Wikipedia).

## Hilfestellungen
In dieser beschäftigen Sie sich mit der Implementierung einer Version des Spiels "Conways Spiel des Lebens". Bei der Implementierung sollen Sie nochmal die Aspekte der prozeduralen Programmierung wiederholen.

Zum besseren Verständnis des Spiels, können Sie auf dieser Website damit herumspielen:  
https://beltoforion.de/de/game_of_life/  
(Sie werden das Spiel des Lebens in einer vereinfachten Form implementieren)


Zusätzlich finden Sie weitere Informationen zu dem Spiel Online auf Wikipedia:  
https://de.wikipedia.org/wiki/Conways_Spiel_des_Lebens


Eine Zusammenfassung der Spielregeln finden Sie auch im Übungsblatt. Kernziel der Übung ist es, dass Sie prozedural mit Java programmieren. Als Starthilfe ist Ihnen ein Programmgerüst in GitLab vorgegeben, welches Sie weiter befüllen können. Ihr finales Programm sollte dann die befüllte main-Methode haben, sowie 3 Hilfsfunktionen
````java
private static boolean[][] computeNextGenCells(boolean[][] cells) {

private static int countLivingNeighbors(boolean[][] c, int x, int y) {

private static void printCells(boolean[][] c) {
````
Die main-Methode gibt bereits das Programmgeürst für die Userinteraktion vor.

Tipp:
Der Debugger ist dein bester Freund 😊

Damit ihr Output wie ein echtes Game of Life aussieht ersetzen Sie am besten die Symbole: "X " durch "■ " und "O " durch "░ ".
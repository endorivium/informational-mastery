## Git Download Link: 
[Git Download](https://git-scm.com/downloads)

## Alternativ: 
Git von IntelliJ installieren

## Git Projekt Clonen (in einem passendem Verzeichnis):
```
git clone https://inf-git.th-rosenheim.de/oop-inf/sose25/exercises.git
```
Den Link bekommen Sie von GitLab selbst:

![img.png](img.png)

In GitBash sieht es so aus:

![img_3.png](img_3.png)

Ein Update erhalten Sie über
```
git pull
```
![img_4.png](img_4.png)

## Clone aus IntelliJ heraus:
- ![img_1.png](img_1.png)


- ![img_2.png](img_2.png)

- Wähle hier ein passendes Verzeichnis auf deinem Rechner.
- Klicke "clone"
IntelliJ öffnet dann die Projektstruktur automatisch.
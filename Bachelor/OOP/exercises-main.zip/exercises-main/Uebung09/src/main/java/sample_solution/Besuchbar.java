package sample_solution;
/**
 * Interface besuchbar
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified 	5.4.2020, Silke Lechner-Greite
 */
public interface Besuchbar {
    /**
     * Schnittstellenmethode getTermin()
     * @return Termin
     */
    public Termin getTermin();
}

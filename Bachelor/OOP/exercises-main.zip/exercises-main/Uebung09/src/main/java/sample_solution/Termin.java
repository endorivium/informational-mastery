package sample_solution;
/**
 * Klasse Termin
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified 	5.4.2020, Silke Lechner-Greite
 */
public class Termin {
    // wir legen  derzeit nicht fest,
    // wie dieser Termin aussieht
}

package sample_solution;
/**
 * Klasse Dozent erbt von Person und implementiert die
 * Schnittstelle besuchbar
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified 	5.4.2020, Silke Lechner-Greite
 */
public class Dozent extends Person implements Besuchbar{
    // Objektattribute -- Assoziation zu Veranstaltungen
    private Veranstaltung[] gehalteneVeranstaltungen;

    /**
     * Konstruktor
     * @param vorname
     * @param nachname
     */
    public Dozent(String vorname, String nachname){
        super(vorname,nachname);
    }

    // Implementierung der Schnittstelle besuchbar
    // --> getTermin() muss implementiert werden
    /**
     * Der Dozent ruft seine Termine ab
     * @return Termin
     */
    public Termin getTermin(){
        return null;
    }
}

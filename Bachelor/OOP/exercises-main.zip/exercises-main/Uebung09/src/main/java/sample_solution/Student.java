package sample_solution;
/**
 * Klasse Student erbt von Person
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified 	5.4.2020, Silke Lechner-Greite
 */
public class Student extends Person{
    // Klassenvariable zum Vergeben der Matrikelnummern
    private static int matrikelnummer = 100000;

    // neue Objektattribute
    // auch Objektattribut - so stellen wir die Assoziation zu Veranstaltung her
    private Veranstaltung[] veranstaltungen;
    // auch Objektattribut - so stellen wir die Assoziation zum Kalender her
    private Kalender kalender;

    /**
     * Konstruktor
     * @param vorname
     * @param nachname
     */
    public Student (String vorname, String nachname){
        super(vorname,nachname);
        this.matrikelnummer += 1;
        System.out.println("Student " + this.toString() +
                ", MtkNr: " + this.matrikelnummer + " wurde angelegt.");
    }
    public int getMatrikelnummer() {return this.matrikelnummer;}

    public void addVeranstaltung(Veranstaltung v) {
        Veranstaltung[] neu = new Veranstaltung[veranstaltungen.length+1];
        for(int i=0;i<veranstaltungen.length;i++){
            neu[i]=veranstaltungen[i];
        }
        neu[veranstaltungen.length]=v;
        this.veranstaltungen=neu;
    }

    public void exmatrikulieren(Student student) {
        this.setVorname("");
        this.setNachname("");
        this.veranstaltungen = null;
        this.kalender = null;
        this.matrikelnummer -= 1;

    }
}

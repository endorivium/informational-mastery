package sample_solution;
/**
 * Ausführendes Programm Startup
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified 	5.4.2020, Silke Lechner-Greite
 */
public class startup {
    public static void main (String[] args){

        Student s1= new Student("Michael", "Mustermann");
        Student s2= new Student("Adam", "Apfel");
        Student s3= new Student("Eva", "Melone");
        Dozent d = new Dozent("Paula","Programm");

        Veranstaltung oop = new Veranstaltung("OOP",2,
                new Student[] {s1,s2,s3},d);
        System.out.println(oop.toString());

        s1.addVeranstaltung(oop);


    }
}

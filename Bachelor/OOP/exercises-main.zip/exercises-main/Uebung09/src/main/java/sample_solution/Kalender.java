package sample_solution;
/**
 * Klasse Kalender
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified 	5.4.2020, Silke Lechner-Greite
 */
public class Kalender {
    // Objektattribute -- Komposition zu Terminen
    Termin[] termine;

    /**
     * Fügt ein Termin vom Typ besuchbar dem Kalender hinzu
     * @param ereignis
     */
    public void addTermin (Besuchbar ereignis){
    }
}

package sample_solution;
/**
 * Abstrakte Klasse Person
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified 	5.4.2020, Silke Lechner-Greite
 */
public abstract class Person {
    // Objektattribute
    private String vorname;
    private String nachname;

    /**
     * Konstruktor
     * @param vorname
     * @param nachname
     */
    public Person (String vorname, String nachname){
        this.vorname = vorname;
        this.nachname = nachname;
    }

    protected String getVorname() {return this.vorname;}
    protected String getNachname() {return this.nachname;}
    protected void setVorname(String vorname) { this.vorname=vorname;}
    protected void setNachname(String nachname) { this.nachname=nachname;}

    public String toString() {
        return this.vorname + " " + this.nachname;
    }
}

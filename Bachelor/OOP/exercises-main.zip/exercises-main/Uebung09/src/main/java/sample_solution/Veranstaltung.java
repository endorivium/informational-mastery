package sample_solution;
/**
 * Klasse Veranstaltung
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified 	5.4.2020, Silke Lechner-Greite
 */
public class Veranstaltung implements Besuchbar{
    // Objektattribute
    private String name;
    private int semester;
    // auch Objektattribute - realisiert Assoziation zu Student und Dozent
    private Student[] studenten;
    private Dozent betreuer;

    /**
     * Konstruktor mit name und semester als Input
     * Studenten und Dozent werden nicht definiert
     * @param name
     * @param semester
     */
    public Veranstaltung(String name, int semester) {
        this.name = name;
        this.semester=semester;
        this.studenten = new Student[0];
        this.betreuer = new Dozent("","");
    }

    public Veranstaltung(String name, int semester, Student[] studenten, Dozent dozent) {
        this.name = name;
        this.semester=semester;
        this.studenten = studenten;
        this.betreuer = dozent;
    }

    public void addStudent(Student student) {
        Student[] neu = new Student[studenten.length+1];
        for(int i=0;i<studenten.length;i++){
            neu[i]=studenten[i];
        }
        neu[studenten.length]=student;
        this.studenten=neu;
    }

    public void setDozent(Dozent dozent) {
        this.betreuer=dozent;
    }

    /**
     * toString um Veranstaltung zu beschreiben
     * @return String
     */
    public String toString() {
        return "Veranstaltung: " + this.name + " - Sem " + this.semester + " - Dozent: " +
                this.betreuer.toString();
    }

    /**
     * Getter für Studentenarray
     * @return Student[]
     */
    public Student[] getStudenten() {
        return this.studenten;
    }

    // Implementierung der Schnittstelle besuchbar
    // --> getTermin() muss implementiert werden
    /**
     * Aus der Liste der Veranstaltungen kann ein Termin ausgelesen werde
     * @return Termin
     */
    public Termin getTermin(){
        return null;
    }

}

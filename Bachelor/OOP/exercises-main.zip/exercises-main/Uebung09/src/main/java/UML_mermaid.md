```mermaid

classDiagram
    direction LR
    class Besuchbar {
        <<Interface>>
        + getTermin() Termin
    }
    class Dozent {
        + Dozent(String, String)
        - Veranstaltung[] gehalteneVeranstaltungen
        + getTermin() Termin
    }
    class Kalender {
        + Kalender()
        ~ Termin[] termine
        + addTermin(besuchbar) void
    }
    class Person {
        + Person(String, String)
        - String nachname
        - String vorname
        # getVorname() String
        # getNachname() String
        + toString() String
        # setVorname(String) void
        # setNachname(String) void
    }
    class Student {
        + Student(String, String)
        - Veranstaltung[] veranstaltungen
        - Kalender kalender
        - int matrikelnummer
        + exmatrikulieren(Student) void
        + getMatrikelnummer() int
        + addVeranstaltung(Veranstaltung) void
    }
    class Termin {
        + Termin()
    }
    class Veranstaltung {
        + Veranstaltung(String, int)
        + Veranstaltung(String, int, Student[], Dozent)
        - Dozent betreuer
        - Student[] studenten
        - int semester
        - String name
        + setDozent(Dozent) void
        + addStudent(Student) void
        + getStudenten() Student[]
        + getTermin() Termin
        + toString() String
    }


    Dozent --|> Person
    Student --|> Person
    Dozent "1" *--> "gehalteneVeranstaltungen *" Veranstaltung
    Kalender "1" *--> "termine *" Termin
    Student "1" *--> "kalender 1" Kalender
    Student "1" *--> "veranstaltungen *" Veranstaltung
    Veranstaltung ..> Besuchbar
    Veranstaltung "1" *--> "betreuer 1" Dozent
    Veranstaltung "1" *--> "studenten *" Student
    
```
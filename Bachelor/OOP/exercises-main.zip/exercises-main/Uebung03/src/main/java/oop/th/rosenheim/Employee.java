package oop.th.rosenheim;

public class Employee {
}

package sample_solution.GameOfLifeObjektorientiert;

/**
 * Entspricht einer Zelle des Game of Lifes
 */
public class Cell {
    private int x;
    private int y;
    private boolean isAlive;

    public Cell(int x, int y) {
        this.x = x;
        this.y = y;
        isAlive = Math.random() < 0.5;
    }

    public Cell(int x, int y, boolean isAlive) {
        this(x, y);
        this.isAlive = isAlive;
    }

    public boolean isAlive() {
        return isAlive;
    }

    @Override
    public String toString() {
        if (this.isAlive) {
            return "X";
        }

        return "O";
    }
}

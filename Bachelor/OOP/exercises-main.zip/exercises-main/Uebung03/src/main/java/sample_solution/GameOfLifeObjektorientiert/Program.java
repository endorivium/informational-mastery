package sample_solution.GameOfLifeObjektorientiert;

import java.util.Scanner;

/**
 * Einstiegspunkt unserer Anwendung
 */
public class Program {
    private static int HEIGHT = 10;
    private static int WIDTH = 10;

    public static void main(String[] args) {
        GameOfLife gameOfLife = new GameOfLife(HEIGHT, WIDTH);

        // print out first generation
        System.out.println("Generation #1");
        gameOfLife.printCells();

        Scanner scanner = new Scanner(System.in);
        int i = 1;
        do {
            gameOfLife.computeNextGenCells();
            System.out.println("Generation #:" + (++i));
            gameOfLife.printCells();
            System.out.println("Should I compute another generation? 'y' for \"yes\"");
        } while (scanner.next().equals("y"));

        System.out.println("Terminating");

    }
}

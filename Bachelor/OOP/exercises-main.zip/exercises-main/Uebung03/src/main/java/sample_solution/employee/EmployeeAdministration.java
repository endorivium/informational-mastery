package sample_solution.employee;

import java.util.Scanner;

/**
 * EmployeeVerwaltung, um Employees zu verwalten
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified	    19.3.2025, Silke Lechner-Greite
 */
public class EmployeeAdministration {

    private Employee[] employees;
    private int count; // Zählt die Anzahl der tatsächlich gespeicherten Employees

    /**
     * Erzeugt ein EmployeeVerwaltungs Objekt.
     * @param maxEmployees Gibt die maximale Anzahl an Employees vor.
     */
    public EmployeeAdministration(int maxEmployees) {
        employees = new Employee[maxEmployees];
        count = 0;
    }

    /**
     * Fügt einen Employee zur Verwaltung hinzu.
     * @param employee Das Employee-Objekt
     */
    public void addEmployee(Employee employee) {
        if (count < employees.length) {
            employees[count] = employee;
            count++;
        } else {
            System.out.println("Mitarbeiterliste ist voll! Neuer Mitarbeiter kann nicht hinzugefügt werden.");
        }
    }

    /**
     * Fragt den Benutzer nach einem Gehalt für einen spezifischen Mitarbeiter
     * und setzt dieses über die setSalary-Methode.
     */
    public void setSalaryFromUserInput(int index) {
        if (index < 0 || index >= count) {
            System.out.println("Ungültiger Index.");
            return;
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Geben Sie das Gehalt für " + employees[index].getName() + " ein: ");

        if (scanner.hasNextFloat()) {
            float salary = scanner.nextFloat();
            employees[index].setSalary(salary);
        } else {
            System.out.println("Ungültige Eingabe. Gehalt wird nicht gesetzt.");
        }
    }

    /**
     * Berechnet das Durchschnittsgehalt aller Mitarbeiter.
     * @return Durchschnittsgehalt als gerundeter Wert
     */
    public float calculateAverageSalary() {
        if (count == 0) return 0;

        float sum = 0;
        for (int i = 0; i < count; i++) {
            sum += employees[i].getSalary();
        }

        return Math.round(sum / count);
    }

    /**
     * Gibt alle Mitarbeiter mit Name und Gehalt aus.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Angestelltenliste:\n");
        for (int i = 0; i < count; i++) {
            sb.append(employees[i].toString() + "\n");
        }
        return sb.toString();
    }
}
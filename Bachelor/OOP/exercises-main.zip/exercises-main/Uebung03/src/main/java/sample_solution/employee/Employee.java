package sample_solution.employee;
/**
 * Klasse "Employee" des Verwaltungsprogramms
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created on 	    16.3.2016, Wolfgang Mühlbauer
 * Modified	        19.3.2025, Silke Lechner-Greite
 */
public class Employee {

    // ATTRIBUTES
    private String name;
    private float salary;

    // CONSTRUCTORS

    /**
     * Erstellt einen Employee mit einem Namen und einem Standardgehalt von 0.
     * @param name Name des Mitarbeiters
     */
    public Employee(String name) {
        this(name, 0);
    }

    /**
     * Erstellt einen Employee mit Name und Gehalt.
     * @param name Name des Mitarbeiters
     * @param salary Monatsgehalt des Mitarbeiters
     */
    public Employee(String name, float salary) {
        setName(name);
        setSalary(salary);
    }

    // GETTER

    public String getName() {
        return name;
    }

    public float getSalary() {
        return salary;
    }

    // SETTER

    /**
     * Setzt das Gehalt des Mitarbeiters.
     * Das Gehalt darf zwischen 0 und 50.000 Euro liegen.
     * @param salary Monatsgehalt des Mitarbeiters
     */
    public void setSalary(float salary) {
        if (salary >= 0 && salary <= 50000) {
            this.salary = salary;
        } else {
            System.out.println("Ungültiges Gehalt: " + salary + " €. Das Gehalt bleibt unverändert.");
        }
    }

    /**
     * Setzt den Namen des Mitarbeiters. Falls ein ungültiger Name übergeben wird,
     * wird "Unbekannt" als Standardwert gesetzt.
     * @param name Name des Mitarbeiters
     */
    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
        } else {
            this.name = "Unbekannt";
        }
    }

    // TO STRING METHOD

    @Override
    public String toString() {
        return name + " | " + salary + " €";
    }

}
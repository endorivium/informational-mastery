package sample_solution.GameOfLifeObjektorientiert;

/**
 * Verwaltungsklasse für ein Game of Life Feld
 */
public class GameOfLife {

    private Cell[][] cells;

    public GameOfLife(int height, int width) {
        this.cells = new Cell[height][width];

        for (int y = 0; y < height; y++){
            for (int x = 0; x < width; x++){
                this.cells[y][x] = new Cell(x, y);
            }
        }
    }

    private int countLivingNeighbors(int x, int y) {
        int count = 0;
        for (int offsetY = -1; offsetY < 2; offsetY++) {
            for (int offsetX = -1; offsetX < 2; offsetX++) {
                int neighborY = y + offsetY;
                int neighborX = x + offsetX;

                //Check if indices are within bounds
                if (neighborX >= 0 && neighborY >= 0 && neighborY < this.cells.length && neighborX < this.cells[0].length) {
                    if ((neighborX != x || neighborY != y) && this.cells[neighborY][neighborX].isAlive()) {
                        count++;
                    }
                }
            }
        }

        return count;
    }

    public void computeNextGenCells() {
        Cell[][] result = new Cell[this.cells.length][this.cells[0].length];

        for (int y = 0; y < this.cells.length; y++) {
            for (int x = 0; x < this.cells[y].length; x++) {
                int livingNeighbors = countLivingNeighbors(x, y);

                if (this.cells[y][x].isAlive() && (livingNeighbors == 2 || livingNeighbors == 3)) {
                    result[y][x] = new Cell(x, y, true);
                } else if (!this.cells[y][x].isAlive() && livingNeighbors == 3) {
                    result[y][x] = new Cell(x, y, true);
                } else {
                    result[y][x] = new Cell(x, y, false);
                }
            }
        }

        this.cells = result;
    }

    public void printCells() {
        for (int y = 0; y < this.cells.length; y++) {
            for (int x = 0; x < this.cells[0].length; x++) {
                System.out.print(this.cells[y][x]);
            }
            System.out.println();
        }
    }

}

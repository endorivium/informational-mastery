package sample_solution.employee;

/**
 * Testprogamm, welches die Verwaltungssoftware der Employees ausführt
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified	    19.3.2025, Silke Lechner-Greite
 */
public class TestEmployee {
    public static void main(String[] args) {

        // Verwaltung mit Platz für 3 Mitarbeiter erstellen
        EmployeeAdministration verwaltung = new EmployeeAdministration(3);

        // Mitarbeiter erzeugen und zur Verwaltung hinzufügen
        verwaltung.addEmployee(new Employee("Alice", 30000));
        verwaltung.addEmployee(new Employee("Bob", 45000));
        verwaltung.addEmployee(new Employee("Charlie")); // Gehalt noch nicht gesetzt

        // Benutzer nach Gehalt für Charlie fragen
        verwaltung.setSalaryFromUserInput(2);

        // Durchschnittsgehalt berechnen und ausgeben
        System.out.println("Durchschnittsgehalt: " + verwaltung.calculateAverageSalary() + " €");

        // Alle Mitarbeiter ausgeben
        System.out.println(verwaltung);
        System.out.println();
    }
}

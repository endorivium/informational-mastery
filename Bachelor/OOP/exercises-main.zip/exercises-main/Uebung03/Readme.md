# Übung 03: Klassen und Objekte

- [Intro zu Übung 3](Hilfestellungen/Intro_Uebung_3.pdf)
- In dieser Übung tasten wir uns an die objektorientierte Programmierung heran. Ziel ist es, eine einfache Software zu entwickeln, die die Angestellten (engl. *Employees*) einer Firma verwaltet und verschiedene administrative Aufgaben übernimmt.


## Kernthemen
- Unterscheidung von Klassen und Objekten
- Anwendung von Settern/Gettern und Konstruktoren
- Implementierung von Referenztypen (new Object())
- Aufruf von Methoden und Variablen

## Aufgabe 1: Implementierung der Klasse Employee
Jeder Angestellte hat einen Namen und ein Monatsgehalt. Für das Monatsgehalt soll zwingend der
Datentyp float verwendet werden.

- **Attribute:**
  - `name` (Datentyp: `String`) – Name des Angestellten
  - `salary` (Datentyp: `float`) – Monatsgehalt des Angestellten

Jedem Objekt der Klasse Employee muss ab dem Zeitpunkt der Initialisierung ein Name
zugewiesen sein. Falls der Benutzer einen ungültigen Namen eingibt (z. B. null oder ""), soll ein Standardname gesetzt werden. Optional kann mit der Initialisierung auch gleich das Monatsgehalt festgelegt werden. Wie könnte man das erreichen?

- **Konstruktoren:**
  - Ein Konstruktor, der nur den Namen übergibt und das Gehalt auf `0` setzt.
  - Ein Konstruktor, der sowohl den Namen als auch das Gehalt initialisiert.


Die Klasse Employee verfügt über eine Methode, mit der man das Gehalt auf einen Wert setzen
kann. Ein Gehalt von mehr als 50000 Euro wird abgelehnt und das Gehalt bleibt dann unverändert Falls ein ungültiges Gehalt eingegeben wird, soll eine Meldung ausgegeben werden. Das Gehalt darf ausschließlich über eine Methode modifiziert werden (Setter). Weiter verfügt die Klasse über Methoden, um das Gehalt und den Namen auszulesen (Getter). Die Klasse hat eine Methode, die eine Zeichenkette mit dem Namen und dem Gehalt zurückliefert (toString).
- **Methoden:**
  - `setSalary(float salary)`: Setzt das Gehalt auf einen neuen Wert. Es darf maximal `50.000€` betragen. Werte über dieser Grenze werden abgelehnt.
  - `getSalary()`: Gibt das aktuelle Gehalt zurück.
  - `getName()`: Gibt den Namen des Mitarbeiters zurück.
  - `toString()`: Gibt eine Zeichenkette mit Name und Gehalt in der Form `<name> | <salary> €` zurück.

Implementieren Sie die Klasse `Employee.java` gemäß den oben beschriebenen Vorgaben.


## Aufgabe 2: Implementierung der Klasse `EmployeeAdministration`
Erstellen Sie in Ihrem IntelliJ Projekt eine Verwaltungsklasse `EmployeeAdministration`, die mehrere Angestellte speichert und verschiedene Verwaltungsfunktionen bereitstellt.

- **Attribute:**
  - Ein Array von `Employee`-Objekten zur Speicherung der Angestellten.
  - Eine Variable `count`, die die Anzahl der aktuell gespeicherten Mitarbeiter zählt.

- **Methoden:**
  - `addEmployee(Employee employee)`: Fügt einen neuen Angestellten zur Verwaltung hinzu.
  - `setSalaryFromUserInput(int index)`: Fragt den Benutzer nach einem Gehalt für einen bestimmten Mitarbeiter und setzt dieses.
  - `calculateAverageSalary()`: Berechnet das Durchschnittsgehalt aller Angestellten und gibt das gerundete Ergebnis zurück (Math.round()).
  - `toString()`: Gibt alle Angestellten mit Name und Gehalt zurück.

Implementieren Sie die Klasse `EmployeeAdministration.java` gemäß den oben beschriebenen Vorgaben!

## Aufgabe 3: Implementierung der Testklasse `TestEmployee`

Schreiben Sie eine Klasse `TestEmployee`, die die vorherigen Klassen testet. Hier befindet sich die `main()`-Methode:

1. Erstellen Sie eine Instanz der `EmployeeAdministration` mit Platz für drei Mitarbeiter.
2. Erstellen Sie drei `Employee`-Objekte:
- Zwei mit einem festgelegten Gehalt.
- Ein drittes ohne Gehalt.
3. Fügen Sie alle drei Angestellten zur `EmployeeAdministration` hinzu.
4. Fragen Sie den Benutzer in der Konsole nach dem Gehalt für den dritten Angestellten und setzen Sie es entsprechend.
5. Berechnen Sie das Durchschnittsgehalt und geben Sie es aus.
6. Geben Sie alle Mitarbeiter mit Namen und Gehalt über `toString()` aus.

## **Zusatzhinweise**
- Nutzen Sie `Scanner` für die Benutzereingaben.
- Verwenden Sie `Math.round()`, um das Durchschnittsgehalt auf eine Ganzzahl zu runden.
- Achten Sie auf korrekte Sichtbarkeiten (`private`, `public`) für Attribute und Methoden.
- Testen Sie Ihre Lösung in IntelliJ oder einer anderen Entwicklungsumgebung.

---
## Hilfestellungen
Zur Wiederholung von Klassen und Objekten können Sie sich folgenden Videoclips anschauen:
- https://www.youtube.com/watch?v=xmSGwipW6NQ
- https://www.youtube.com/watch?v=FKdxjjNdCYM
- https://www.youtube.com/watch?v=WKL0gObL6ks
- https://www.youtube.com/watch?v=haaJN5gewZA

## Erzeugen von Objekten:
```
Employee alice = new Employee("Alice", 30000);
 ```
1. Typ des Objekts
2. Name des Objekts
3. Schlüsselwort new erzeugt das Objekt (Konstruktoraufruf)
4. Parameter für Konstruktor

---
## [Optional:]
Überführen Sie die GameOfLive Implementierung aus der vorherigen Übung in eine Objekt-Orientierte Lösung!
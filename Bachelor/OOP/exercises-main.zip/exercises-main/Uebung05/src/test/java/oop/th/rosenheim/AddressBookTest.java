package oop.th.rosenheim;

class AddressBookTest {

}
package sample_solution;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AddressBookTest {

    private static Contact[] contacts;
    private static AddressBook addressbook;

    @BeforeEach
    void setup() {
        contacts = new Contact[3];
        contacts[0] = new Contact("Berger", 31232);
        contacts[1] = new Contact("Huber", 83882);
        contacts[2] = new Contact("Maier", 29399);

        addressbook = new AddressBook();

        for (Contact c : contacts) {
            addressbook.insertToFront(c);
        }
    }

    @Test
    void checkContactsOrderAfterInsertToFront() {
        setup();
        String expected = "[Maier-29399][Huber-83882][Berger-31232]";
        assertEquals(expected, addressbook.toString());
    }

    @Test
    void findContactContainedInAddressBook() {
        setup();
        Contact foundContact = addressbook.search("Huber");
        assertNotNull(foundContact);
        assertEquals(83882, foundContact.getPhone());
    }

    @Test
    void findContactNotContainedInAddressBook() {
        setup();
        Contact foundContact = addressbook.search("Schmitt");
        assertNull(foundContact);
    }

    @Test
    void deleteContactAtEndOfList() {
        setup();
        addressbook.delete(contacts[0]);
        String expected = "[Maier-29399][Huber-83882]";
        assertEquals(expected, addressbook.toString());
    }
}


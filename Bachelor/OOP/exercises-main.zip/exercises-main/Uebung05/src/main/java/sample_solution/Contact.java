package sample_solution;
/**
 * Die Klasse Contact 
 *
 * @author  	Professoren der Informatikfakultät
 * @version     1.0 
 * Modified 	    6.4.2016, Wolfgang Mühlbauer
 * Modified	        4.4.2020, Silke Lechner-Greite
 */
 
public class Contact {

    // instance counter: static member is used to generate id of a contact
    private static int contactCounter = 0;

    // reference to next node in chain, or null if there isn't one.
    private Contact next;

    // attributes
    private String name;
    private long phone;
    private int id;


    // value constructor 1: phone number unknown, set to 0
    public Contact(String name) {
        contactCounter++;
        id = contactCounter;
        this.name = name;
        this.next = null;
        this.phone = 0;
    }

    // value constructor 2: also sets phone number
    public Contact(String name, long phone) {
        this(name);   // call other constructor
        this.phone = phone;
    }


    // string representation of contact including name and phone
	// overrides toString that is existent for every object
    @Override
    public String toString() {
        return name + "-" + phone;
    }

	// getter - methods
    public long getPhone() {
        return phone;
    }

    public String getName() {
        return name;
    }

    public Contact getNext() {
        return next;
    }

	// setter for next node element
    public void setNext(Contact next) {
        this.next = next;
    }


}

---
marp: true
theme: uncover
paginate: true
---

# Einführung in die Objektvernetzung

### Statische Attribute, Methoden & Verkettete Listen

#### Philipp Brünken
---

### Vernetzung von Objekten?

- Objekte enthalten Referenzen auf andere Objekte
- Ermöglicht die Bildung komplexer Datenstrukturen wie Listen, Bäume, Graphen
- In unserem Fall: **einfach verkettete Liste**

---

### Implementierung der Klasse `Wagon`

- Jeder `Wagon` kennt seinen Nachfolger (`next`)
- ID wird automatisch vergeben 
- Modellierung gemäß UML Diagramm:

|UML|Java|
|--------|-------------|
|-name: String| private String name;|
|+Wagon(name:String)|public Wagon(String name)|
|+getName(): String|public String getName()|


---

### Die Klasse `Caravan`

- Hält den Anfang der Karavane (`head`)
- Methoden zum Einfügen, Suchen, Löschen und Drucken

```java
public class Caravan {
    private Wagon head;
    private int numWagons;

    public void insertToFront(Wagon c) {
        c.next = head;
        head = c;
        numWagons++;
    }
}
```

---

### Suche in verketteten Listen

- Suche durch sequentielles Durchlaufen  

```java
public Wagon search(Wagon wagon) {
    Wagon current = head;
    while (current != null) {
        if (current.equals(wagon)) 
            return current;
        current = current.next;
    }
    return null;
}
```
---

### Löschen eines Eintrags
- Löschen durch Referenz auf Vorgänger-Element

```java
public void deleteByName(String name) {
    Wagon current = head, prev = null;
    while (current != null) {
        if (current.getName().equals(name)) {
            if (prev == null) 
                head = current.next;
            else 
                prev.next = current.next;
            numWagons--;
            return;
        }
        prev = current;
        current = current.next;
    }
}
```
---

### Ausgabe & Übersicht

- Alle Kontakte werden durchlaufen und ausgegeben:

```java
public void print() {
    Wagon current = head;
    while (current != null) {
        System.out.println(current);
        current = current.next;
    }
}
```

- Anzahl der Kontakte wird durch `numWagons` verfolgt
- Verkettung über `next`-Referenzen sichtbar

---


## Zusammenfassung


- **Verkettete Listen** nutzen Referenzen zwischen Objekten zur Strukturierung  
- Durch Verkettung einfacher Objekte entstehen komplexe Strukturen  
- Grundlage für viele weiterführende Datenstrukturen


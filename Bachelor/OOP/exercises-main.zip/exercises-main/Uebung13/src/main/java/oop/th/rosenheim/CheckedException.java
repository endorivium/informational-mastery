package oop.th.rosenheim;

public class CheckedException extends Exception{

    @Override
    public String getMessage() {
        return "Hallo";
    }
}

package sample_solution;

public class TestMain {
	public static void main(String[] args) {
		Year y = Year.requestBirthYear();
		Month m = Month.requestBirthMonth();
		Day d = Day.requestBirthDay(y, m);
		
		System.out.println("Sie haben am " + d.getDay() + "." + m.getMonth() + "." + y.getYear() + " Geburtstag.");
	}
}

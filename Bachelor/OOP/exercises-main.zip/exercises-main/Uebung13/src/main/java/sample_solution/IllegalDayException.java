package sample_solution;

public class IllegalDayException extends Exception {
	public IllegalDayException() {
	}
	
	public IllegalDayException(String m) {
		super(m);
	}
}

package sample_solution;

import java.util.Scanner;

public class Year {
	private int year = 0;
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public Year(int year) {
		this.year = year;
	}
	
	public static Year requestBirthYear() {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Bitte geben Sie Ihr Geburtsjahr ein:");
			String s = sc.nextLine();
			if (s == null)
				break;
			
			try {
				int i = Integer.parseInt(s);  // NumberFormatException?
				return new Year(i);
			} catch (NumberFormatException e) {
				System.out.println("Hoppla, das war keine Zahl!");
				e.printStackTrace(System.out);
			}
		}
		
		// Keine Texteingabe!
		sc.close();
		return null;
	}
}

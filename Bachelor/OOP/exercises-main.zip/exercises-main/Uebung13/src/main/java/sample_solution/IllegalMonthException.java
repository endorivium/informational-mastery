package sample_solution;

public class IllegalMonthException extends Exception {


}

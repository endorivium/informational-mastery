package sample_solution;

import java.util.Scanner;

public class Month {
	private int month = 0;
	public Month(int month) {
		this.month = month;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	
	public static Month requestBirthMonth() {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Bitte geben Sie Ihren Geburtsmonat ein:");
			String s = sc.nextLine();
			if (s == null)
				break;
			
			try {
				int i = Integer.parseInt(s);  // NumberFormatException?
				
				if (i < 1 || i > 12)
					throw new IllegalMonthException();
				
				return new Month(i);
			} catch (IllegalMonthException e) {
				System.out.println("Ungueltige Eingabe: Der Monat muss zwischen 1 und 12 liegen");
				e.printStackTrace(System.out);
			} catch (NumberFormatException e) {
				System.out.println("Hoppla, das war keine Zahl!");
				e.printStackTrace(System.out);
			}
		}
		
		// Keine Texteingabe!
		sc.close();
		return null;
	}
}

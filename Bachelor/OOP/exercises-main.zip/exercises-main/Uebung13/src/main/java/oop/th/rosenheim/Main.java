package oop.th.rosenheim;

import java.util.Arrays;

public class Main {

    public static void main(String[] args){
        try {
            throw new CheckedException();
        } catch (CheckedException e) {
            e.printStackTrace(System.out);
        }
    }
}

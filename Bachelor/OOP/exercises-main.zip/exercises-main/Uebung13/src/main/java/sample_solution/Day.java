package sample_solution;

import java.util.Scanner;

public class Day {
	private int day = 0;
	public Day(int day) {
		this.day = day;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	
	private static void verifyDay(Year y, Month m, Day d) throws IllegalDayException {

		//if (m.getMonth() == 2 && (d.getDay() > 28 && (y.getYear() % 4 != 0 || (y.getYear() % 100 == 0 && y.getYear() % 400 != 0))))
		//	throw new IllegalDayException("Tag muss kleiner oder gleich 28 sein (" + y.getYear() + " ist kein Schaltjahr)");

		// add other checks for proper days, for example 30 vs 31 days per month
		// more work needed ....
		switch (m.getMonth()) {
			case 4, 6, 9, 11:
				if (d.getDay() < 1 || d.getDay() > 30)
					throw new IllegalDayException("Tag muss kleiner oder gleich 30 sein");
				break;
			case 1, 3, 5, 7, 8, 10, 12:
				if (d.getDay() < 1 || d.getDay() > 31)
					throw new IllegalDayException("Tag muss kleiner oder gleich 31 sein");
				break;
			case 2:
				if (d.getDay() == 29 && (y.getYear() % 4 != 0 || (y.getYear() % 100 == 0 && y.getYear() % 400 != 0)))
					throw new IllegalDayException("" + y.getYear() + " ist kein Schaltjahr)");
				else if (d.getDay() < 1 || d.getDay() > 29) {
					throw new IllegalDayException("Tag muss kleiner oder gleich 28");
				}
				break;
		}

	}
	
	public static Day requestBirthDay(Year y, Month m) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Bitte geben Sie Ihren Geburtstag ein:");
			String s = sc.nextLine();
			if (s == null)
				break;
			
			try {
				int i = Integer.parseInt(s);  // NumberFormatException?
				Day d = new Day(i);
				verifyDay(y, m, d);  // IllegalDayException?
				return d;
			} catch (IllegalDayException e) {
				System.out.println(e.getMessage());
				e.printStackTrace(System.out);
			} catch (NumberFormatException e) {
				System.out.println("Hoppla, das war keine Zahl!");
				e.printStackTrace(System.out);
			}
		}
		
		// Keine Texteingabe!
		sc.close();
		return null;
	}
}

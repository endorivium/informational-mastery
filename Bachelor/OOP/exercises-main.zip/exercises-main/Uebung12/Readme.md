# Übung 12: Java Collections

In dieser Übung arbeiten Sie mit dem Java Collections Framework. Hierzu müssen wir auch ein wenig das Konzept über Generics verstehen.

## Kernthemen
- Schreiben von eigenen generischen Klassenmethoden
- Anwendung von generischen Typen
- Grundlegende Funktionalität von Collections and Maps verstehen
  - Welche Collection bzw. Map ist für welchen Zweck geeignet
- Iterieren über eine Collection bzw. Map mit einem Iterator
  - Wie kommt man an die einzelnen Elemente bzw. Key-Value-Paare

## Aufgabe 1: Listen

* Implementieren Sie in einer neuen leeren Klasse `Util` die folgende statische Methode:

````java
public static <T> void reverseInPlace(List<T> list)
````

Die Methode verwendet Generics (Typvariable `T`) und soll mit beliebigen Objekten/Elementen `T`
ausführbar sein. Diese Methode kehrt die Reihenfolge aller Elemente in der Liste `list` um. Die
übergebene Liste wird verändert und deshalb keine neue Liste angelegt.

<br>

* Implementieren Sie zusätzlich die folgende statische Methode:

````java
public static <T> List<T> reverseImmutable(List<T> list)
````
Die Methode erstellt eine neue (!) Liste, die alle Elemente der übergebenen Liste `list` enthält, allerdings in der umgekehrten Reihenfolge. Die zurückgegebene Liste soll exakt den gleichen
Datentyp haben wie die übergebene Liste.

**Hinweise:**
- Sie wissen nicht, ob hinter der übergebenen Liste z.B. eine `ArrayList` oder eine `LinkedList` steckt. Dennoch können Sie eine neue, leere Instanz der übergebenen Liste `list`
  erzeugen.
- Eine neue Instanz der Liste erhält man über: ````list.getClass().newInstance();````

<br>

* Testen Sie Ihre beiden Methoden mit der vorgegebenen JUnit-Testklasse `TestUtil`.

## Aufgabe 2: Mengen, assoziative Speicher, Arrays

Gegeben ist ein Array von Listen. Jeder Eintrag des Arrays entspricht der Seite eines Buches und speichert eine Liste der Schlüsselwörter, die für diese Seite zu indizieren sind. Beispiel:

````
Buchseite 0 / Array-Index 0: → Liste: (leer)
Buchseite 1 / Array-Index 1: → Liste: (Java, Bali, Sulawesi)
Buchseite 1 / Array-Index 2: → Liste: (Bali, Sumatra, Lombok)
````
<br>

* Implementieren Sie die folgende statische Methode in der vorgegebenen Klasse `Index`:
````java
public static Map<String, SortedSet<Integer>> makeIndex(List<String>[] keywords)
````
Die Methode erhält ein Array von Listen mit den zu indizierenden Schlüsselwörtern für jede
Buchseite und gibt einen Index zurück. Der zurückgegebene Index entspricht einer `Map`: Als `Key` dient das Schlüsselwort, der `Value` ist eine Menge (keine Duplikate!) von aufsteigend sortierten Seitenzahlen, auf denen das Schlüsselwort vorkommt.  
Ferner soll in der `Map` eine alphabetische Ordnung für die Schlüsselwörter verwendet werden. Welche konkrete Map-Klasse ist somit geeignet - TreeMap oder HashMap?

**Hinweis:** Der Wrapper "Integer" muss verwendet werden, da primitive Datentypen in der Java Collection nicht erlaubt sind.

<br>

* Vervollständigen Sie die Implementierung der vorgegebenen Methode `toString()`, die den Inhalt der Map, also alle Key-Value-Paare, als String zurückgibt.


<br>

* Testen Sie die Klasse mit der vorgegebenen JUnit-Testklasse `TestIndex`.


## Hilfestellungen

Diese Übung fokussiert sich auf das Java Collection Framework.
Um nochmals ins Thema einsteigen zu können, finden Sie hier unterschiedliche Videos:
1. generell zum Thema Collection Framework (deckt fast alle Collections ab): https://www.youtube.com/watch?v=Ma7u6KEKzPE 
2. ein Tutorial speziell zum Thema List: https://www.youtube.com/watch?v=d3QbptJRln4
3. ein Tutorial speziell zum Thema Set: https://www.youtube.com/watch?v=rruCajMgvGA
4. ein Tutorial speziell zum Thema Map: https://www.youtube.com/watch?v=UfBaTKaSSRg
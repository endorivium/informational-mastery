package sample_solution;

import java.util.*;

/**
 * Die Index Klasse zum Implementieren einer "Map"
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created 		3.6.2016, Muehlbauer
 * Modified 	12.4.2020, Silke Lechner-Greite
 */
public class Index {

	/**
	 * generate index (data structure "map") where key is a string that represents the keyword and
	 * value is a set (sorted by increasing page number) with all book pages on which the keyword appears.
	 * 
	 * @param keywordsInBook array of lists where each lists contains the keywords of an individual book page
	 * @return index where key is a String with the keyword, and value how often keyword occurs in book.
	 */
	 public static Map<String, SortedSet<Integer>> makeIndex(List<String>[] keywordsInBook) {

		Map<String, SortedSet<Integer>> result = new TreeMap<>();
		int page = 0;

		for (List<String> keywords : keywordsInBook){ // iterate through book pages --> array
			for (String key : keywords){ // iterate over all keywords on page --> List

				SortedSet<Integer> pagesContainingKeyword = result.get(key); // find keyword in result map

				if(pagesContainingKeyword == null) { // not found? --> create an entry
					pagesContainingKeyword = new TreeSet<>();
					result.put(key, pagesContainingKeyword);
				}
				pagesContainingKeyword.add(page); // add page

			}
			page++; // next page
		}
		return result;
	}


	/**
	 * returns a string with the content of the index (one line per keyword)
	 *
	 * @return string that displays the content of the index.
	 */
	public static String toString(Map<String, SortedSet<Integer>> idx) {

		StringBuffer result = new StringBuffer();

		for (Map.Entry<String, SortedSet<Integer>> e : idx.entrySet()) {

			String keyword = e.getKey();
			SortedSet<Integer> pages = e.getValue();
			result.append(keyword + ": ");

			// iterate over all pages with keyword using for each loop
			for (Integer i : pages) {
			// alternative -> for (int i = 0; i < pages.size(), i++) ....
				result.append(i + " ");
			}
			result.append("\n");

			// alternatively in a single line:
			// result.append(e.getKey() + ": " + e.getValue() + "\n");

		}
		return result.toString();
	}

}

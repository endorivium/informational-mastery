package oop.th.rosenheim;

public class Util {

	/**
	 * reverse the order of the elements in "list". Do not create a new list.
	 *
	 *  @param list list to be reversed
	 *  @return new list with reversed order
	 */

	// ToDo

	/** creates a new list that contains all elements of "list" in the reversed order.
	 *  Data type of result is the same as of "list" if a default constructor exists.
	 *  Otherwise, the result has the data type array list.
	 *
	 *  @param list list to be reversed
	 *  @return result new list with reversed order
	 */

	// ToDo

}

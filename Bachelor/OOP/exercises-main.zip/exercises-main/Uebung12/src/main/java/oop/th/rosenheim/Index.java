package oop.th.rosenheim;

import java.util.List;
import java.util.Map;
import java.util.SortedSet;

/**
 * Die Index Klasse zum Implementieren einer "Map"
 *
 */
public class Index {

	/**
	 * generate index (data structure "map") where key is a string that represents the keyword and
	 * value is a set (sorted by increasing page number) with all book pages on which the keyword appears.
	 * 
	 * @param keywordsInBook array of lists where each lists contains the keywords of an individual book page
	 * @return index where key is a String with the keyword, and value how often keyword occurs in book.
	 */
	public static Map<String, SortedSet<Integer>> makeIndex(List<String>[] keywordsInBook) {

		// Hint 1: Since index must be sorted alphabetically, TreeMap must be used and not HashMap!
		// Hint 2: wrapper "Integer" must be used since primitive data types not allowed in Java Collection
		// Map<String, SortedSet<Integer>> result =
		// TODO
		return null;
	}



	/**
	 * returns a string with the content of the index (one line per keyword)
	 *
	 * @return string that displays the content of the index.
	 */
	public static String toString(Map<String, SortedSet<Integer>> idx) {

		StringBuffer result = new StringBuffer();

		// TODO

		return null;
	}
}

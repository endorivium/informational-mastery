package sample_solution;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;

/**
 * Junit5 Tester to test Util
 *
 * @author  	Professoren und Tutoren der Informatikfakultät
 * @version     2.0<br>
 * Created 	    3.6.2016, Wolfgang Mühlbauer<br>
 * Modified     5.4.2020,  Silke Lechner-Greite<br>
 * Modified		10.03.2021 Bernd Weiß
 */
@DisplayName("Util tests:")
class TestUtil {

	private List<String> testArrayList;
	private List<String> resultArrayList;
	private List<Integer> testLinkedList;
	private List<Integer> resultLinkedList;

	@BeforeEach
	void setUp() {
		testArrayList = new ArrayList<>();
		testArrayList.addAll(
				Arrays.asList(
						"wort1", "wort2", "wort3", "wort4", "wort5"));
		resultArrayList = new ArrayList<>();
		resultArrayList.addAll(
				Arrays.asList(
						"wort5", "wort4", "wort3", "wort2", "wort1"));

		testLinkedList = new LinkedList<>();
		testLinkedList.addAll(
				Arrays.asList(1, 10, 2, 9, 3, 8, 4, 7, 5, 6));

		resultLinkedList = new LinkedList<>();
		resultLinkedList.addAll(
				Arrays.asList(6, 5, 7, 4, 8, 3, 9, 2, 10, 1));

	}

	@Nested
	@DisplayName("reverse in place tests:")
	class TestReverseInPlace {

		@Test
		@DisplayName("ArrayList with String as element type")
		void testReverseInPlace() {
			Util.reverseInPlace(resultArrayList);
			assertEquals(testArrayList, resultArrayList, "The ArrayList wasn't properly reverted!");
		}

		@Test
		@DisplayName("LinkedList with Integer as element type")
		void testReverseInPlace_LinkedList() {
			Util.reverseInPlace(testLinkedList);
			assertEquals(testLinkedList, resultLinkedList, "The LinkedList wasn't properly reverted!");
		}
	}

	@Nested
	@DisplayName("reverseImmutable tests:")
	class TestReverseImmutable {
		@Test
		@DisplayName("ArrayList with String as element type")
		void testReverseImmutable_ArrayList() {
			List<String> outputArrayList = Util.reverseImmutable(testArrayList);
			assertNotSame(resultArrayList, outputArrayList, "Both ArrayLists are the same reference!");
			assertEquals(resultArrayList.getClass(), outputArrayList.getClass(), "Both ArrayLists aren't the same classes!");
			assertEquals(resultArrayList, outputArrayList, "The ArrayList wasn't properly reverted!");
		}

		@Test
		@DisplayName("LinkedList with Integer as element type")
		void testReverseImmutable_LinkedList() {
			List<Integer> outputLinkedList = Util.reverseImmutable(testLinkedList);
			assertNotSame(resultLinkedList, outputLinkedList, "Both LinkedLists are the same reference!");
			assertEquals(resultLinkedList.getClass(), outputLinkedList.getClass(), "Both LinkedLists aren't the same classes!");
			assertEquals(resultLinkedList, outputLinkedList, "The LinkedList wasn't properly reverted!");
		}
	}




}

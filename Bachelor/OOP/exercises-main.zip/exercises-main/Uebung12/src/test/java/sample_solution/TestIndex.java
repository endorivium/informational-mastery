package sample_solution;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.*;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Die TestIndex Klasse
 * @author  	Professoren und Tutoren der Informatikfakultät
 * @version     2.0<br>
 * Created 		3.6.2016, Muehlbauer<br>
 * Modified 	12.4.2020, Silke Lechner-Greite<br>
 * Modified		10.03.2021 Bernd Weiß
 */
@DisplayName("Index tests:")
class TestIndex {

	private static Logger logger = Logger.getLogger(Index.class.getName());

	private List<String>[] book = null;

	@BeforeEach
	void setUp() {
		// generate book with 6 pages and a few keywords

		book = new List[6];

		//	no entries on page 0
		book[0] = new ArrayList<String>();

		book[1] = new ArrayList<String>();
		book[1].addAll(Arrays.asList(
				"otto", "robert", "hugo"
		));

		book[2] = new ArrayList<String>();
		book[2].addAll(Arrays.asList(
				"otto", "ernst", "rudi"
		));

		// no entries on page 3
		book[3] = new ArrayList<String>();

		book[4] = new ArrayList<String>();
		book[4].addAll(Arrays.asList(
				"otto", "hugo", "jack"
		));

		book[5] = new ArrayList<String>();
		book[5].addAll(Arrays.asList(
				"otto", "susi", "jack"
		));
	}

	@Test
	@DisplayName("makeIndex test")
	void testIndex() {
		Map<String, SortedSet<Integer>> idx = Index.makeIndex(book);
		assertEquals(7, idx.size(),"Size of Index");
		assertEquals(4, idx.get("otto").size(),"Pages where otto shows up");
		assertTrue(idx.get("otto").contains(1));
		assertTrue(idx.get("otto").contains(2));
		assertTrue(idx.get("otto").contains(4));
		assertTrue(idx.get("otto").contains(5));
		assertFalse(idx.get("susi").contains(3));

		logger.info("\n" + Index.toString(idx));
	}
}

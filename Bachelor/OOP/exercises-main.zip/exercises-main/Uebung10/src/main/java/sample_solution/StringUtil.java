package sample_solution;
import java.util.Arrays;
import java.util.Locale;

/**
 * Programm StringUtil
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created      20.4.2017, Wolfgang Mühlbauer
 * Modified 	5.4.2020, Silke Lechner-Greite
 */

public class StringUtil {
    /**
     * extracts all String tokens (delimiter: whitespaces) and sort tokens
     * @param s string from which to extract tokens
     * @return  array of (sorted) strings
     */
    public static String[] string2StringArray(String s) {
        String[] parts = s.split("\\s+"); // delimiter -> whitespaces
        Arrays.sort(parts);
        return parts;
    }


    /**
     * joins elements of a String array to a single string; adding 1 whitespace between the different elements
     * (Arrays.toString or join method not allowed) --> String Buffer
     * @param arr array of strings
     * @return result
     */
    public static String stringArray2String(String[] arr) {
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < arr.length; ++i) {
            buf.append(arr[i]);
            if (i < arr.length - 1) buf.append(" ");
        }
        return buf.toString();
    }


    /**
     * checks if two strings are anagrams
     * @param string1
     * @param string2
     * @return true if both strings are anagrams
     */
    public static boolean areAnagrams(String string1, String string2) {

        System.out.println("String1: " + string1);
        System.out.println("String2: " + string2);
        // Ursprünglich:
        //if (string1.equals(string2)) {// aber so würde dann dasselbe Wort als Anagramm anerkannt, zB bei Sonderzeichen.
        if (removeJunk(string1).equals(removeJunk(string2))) { // dann erspart man sich eine Überprüfung
            return false;
        }
        String workingCopy1 = removeJunk(string1);
        String workingCopy2 = removeJunk(string2);

        workingCopy1 = workingCopy1.toLowerCase();
        workingCopy2 = workingCopy2.toLowerCase();

        workingCopy1 = sort(workingCopy1);
        workingCopy2 = sort(workingCopy2);

        return workingCopy1.equals(workingCopy2);
    }

    /**
     * removes all characters of a string that are not letters
     * @param string
     * @return string without "non-letter" characters
     */
    private static String removeJunk(String string) {
        int i, len = string.length();
        StringBuilder dest = new StringBuilder(len);
        char c;

        for (i = (len - 1); i >= 0; i--) {
            c = string.charAt(i);
            if (Character.isLetter(c)) {
                dest.append(c);
            }
        }
        return dest.toString();
    }

    /**
     * take all characters from a string and form a new string where these letters are alphabetically sorted.
     * @param string
     * @return string with same letters but sorted.
     */
    private static String sort(String string) {
        char[] charArray = string.toCharArray();
        Arrays.sort(charArray);
        return new String(charArray);
    }


    /**
     * creates a string that only contains alphabetic characters
     * @param palindrome
     */
    public static String filter(String palindrome) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < palindrome.length(); i++)
            if (Character.isAlphabetic(palindrome.charAt(i)))
                sb.append(Character.toLowerCase(palindrome.charAt(i)));
        return sb.toString();
    }

    /**
     * Another filter option using regular expressions
     * @param palindrome
     */
    static public String filterRegex(String palindrome) {
        return palindrome.toLowerCase(Locale.ROOT) // convert all to lower case
                .replaceAll("[^a-z]", ""); // replace everything that is not a-z with empty String
    }

    public static boolean isPalindrome(String palindrome) {
        for (int i = 0; i < palindrome.length()/2; i++) {
            if (palindrome.charAt(i) != palindrome.charAt(palindrome.length() - 1 - i)){
                return false;}
        }
        return true;
    }

}

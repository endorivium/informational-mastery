package sample_solution;
import java.util.Scanner;

/**
 * Programm StringOops corrected
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created      19.5.2017, Wolfgang Mühlbauer
 * Modified 	5.4.2020, Silke Lechner-Greite
 */

public class StringOopsSolution {
    /**
     * Main-Methode zum Starten des Programms
     * @param args
     */
    public static void main(String[] args) {
        // Erzeugen eines Scanner Objekts
        Scanner console = new Scanner(System.in);
        // User Input erfragen
        System.out.print("Type your name: ");
        // Text einlesen
        String name = console.next();
        // Eingabe bearbeiten
        process(name);

    }

    /**
     * Bearbeitungsmethode des User Inputs
     * @param name
     */
    public static void process(String name) {       // F1: string -> String (keine Anführungszeichen bei Parameter)
        if (name.equals("Duck")) {                  // F2+3 == -> equals und String in Anführungszeichen
            System.out.println("Hello Donald!");
        }
        name = name.toUpperCase();                  // F4: toUpperCase ist Objektmethode siehe -> name.toUpperCase(.)
                                                    // F5: String ist immutable -> weise Ergebnis Variable zu
        System.out.println(name.substring(1, 3));   // F6+F7: siehe F4, substring liefert einen String zurück
                                                    // dieser soll ausgegeben werden.
                                                    // startIndex von substring() ist inklusive
                                                    // endIndex von substring() ist exklusive.
        System.out.println(name + " has " + name.length() + " letters");  // F8: length() mit Klammern
    }
}

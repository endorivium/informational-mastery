package sample_solution;
import java.util.Arrays;

public class Task1 {

    public static void main(String[] args) {

        // Vergleich von Arrays:
        // "a1 == a2" vergleicht Identität
        //  Arrays.equals( a1, a2 ) vergleicht Inhalt der Arrays --> Array bietet statische Methoden ... Array.xyz
        int[] a1 = {1, 2, 3};
        int[] a2 = {1, 2, 3};
        if (a1 != a2) {
            System.out.println("a1 == a2 ergibt false");
        }
        if (Arrays.equals(a1,a2)) {
            System.out.println("a1 und a2 haben gleichen Inhalt");
        }

        // Vergleich von Strings:
        // "s1 == s2" vergleicht Identität
        //  s1.equals(s2 ) vergleicht Inhalt der Strings
        String s1 = "Hallo";
        String s2 = "Hallo";
        if (s1 != s2) {
            System.out.println("s1 == s2 ergibt false -- zwei unterschiedliche Referenzvariablen");
        }
        /*if (s1.equals(s2)) {
            System.out.println("s1 und s2 sind gleich");
        }*/
        if (s1.compareTo(s2)==0) {
            System.out.println("s1 und s2 sind gleich");
        }
        System.out.println(s1=="Hallo"); // liefert true
        System.out.println("Hallo"=="Hallo");   // liefert true


        String s = "Hallo";
        char c = s.charAt(1);
        char c2 = s.charAt(s.length()-1);

        if (Character.isLetter(c2)) {
            System.out.println("So überprüft man ob das extrahierte Zeichen ein Buchstabe ist.");
        }

        // iteriere über alle Zeichen eines Strings
        for (int i=0; i<s.length(); i++) {
            char c5 = s.charAt(i);
        }

        // Arrays.sort ... vieles mehr

    }
}

package sample_solution;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("StringUtil Tests")
class StringUtilTest {

    @ParameterizedTest
    @ValueSource(strings = {
            "Otto",
            "Blaukraut bleibt Blaukraut und Brautkleid bleibt Brautkleid",
            "Risotto, Sir?",
            "Ein Esel lese nie.",
            "Vitaler Nebel mit Sinn ist im Leben relativ!",
            "Madam",
            "level",
            "A Santa lived as a devil at NASA",
            "Was it a car or a cat I saw?",
            "Eva, can I see bees in a cave?",
            "Never odd or even"
    })
    void isPalindrome_filteredPalindrome_returnsTrue(String text) {
        assertTrue(StringUtil.isPalindrome(StringUtil.filter(text)));
    }

    @Test
    void stringArray2String_emptyArray_returnsEmptyString() {
        assertEquals("", StringUtil.stringArray2String(new String[]{}));
    }

    @Test
    void stringArray2String_oneWord_returnsWord() {
        assertEquals("EinWort", StringUtil.stringArray2String(new String[]{"EinWort"}));
    }

    @Test
    void stringArray2String_multipleWords_joinsWithSpaces() {
        String[] input = {"programmieren", "macht", "spass"};

        String result = StringUtil.stringArray2String(input);

        assertEquals("programmieren macht spass", result);
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "bald sind ferien",
            " bald sind ferien ",
            "\nbald\nsind\nferien\n"
    })
    void string2StringArray_differentWhitespaces_returnsSortedWords(String text) {
        String[] expected = {"bald", "ferien", "sind"};

        String[] result = StringUtil.string2StringArray(text);

        assertArrayEquals(expected, result);
    }

    @Test
    void string2StringArray_sentence_returnsSortedWords() {
        String[] expected = {"auch", "eine", "insel", "ist", "java"};

        String[] result = StringUtil.string2StringArray("java ist auch eine insel");

        assertArrayEquals(expected, result);
    }

    @ParameterizedTest
    @CsvSource({
            "abc, ABC",
            "xyz, zyx",
            "xyz, yxz",
            "xyz, xzy",
            "abc, 012a345b67c89",
            "abc, ' a b c '",
            "abc, '\na\nb\nc'",
            "xyz, '%§x!.y(}z*;'"
    })
    void areAnagrams_borderCases_returnsTrue(String first, String second) {
        assertTrue(StringUtil.areAnagrams(first, second));
        assertTrue(StringUtil.areAnagrams(second, first));
    }

    @ParameterizedTest
    // @CsvSource - mehrere Testfälle direkt in den Test übergeben
    @CsvSource({
            "Tar, Rat",
            "Arc, Car",
            "Elbow, Below",
            "State, Taste",
            "Cider, Cried",
            "Dusty, Study"
    })
    void areAnagrams_validWords_returnsTrue(String first, String second) {
        assertTrue(StringUtil.areAnagrams(first, second));
    }
}
# Übung 10 Strings und Arrays
In dieser Übung beschäftigen Sie sich mit dem Verarbeiten von Texten.

## Kernthemen
- Operationen auf Strings (Splitting, Joining, etc.)
- Operationen aus der Klasse Character anwenden
- StringBuffer und StringBuilder
- Unterschied zwischen Vergleich auf Identität und Gleichheit

## Aufgabe 1: Fehlersuche
Im folgenden (ziemlich sinnlosen) Programm sind Fehler enthalten. Das Programm liest einen Namen von der Kommandozeile. Falls „Duck“ eingegeben wird, so wird der Benutzer mit „Hallo Donald“ begrüßt.
Anschließend gibt das Programm den 2. und 3. Buchstaben der Eingabe als Großbuchstaben aus.

Überlegen Sie sich ohne PC, was falsch ist und korrigieren Sie das Programm! Ggfs. können sie das Programm später in IntelliJ prüfen.

```java
public class StringOops {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        System.out.print("Type your name: ");
        String name = console.next();
        process(name);
    }

    public static void process(string "name") {
        if (name == Duck) {
            System.out.println("Hello Donald!);
        }
        toUpperCase(name);
        name.substring(1, 3);
        System.out.println(name + " has " + name.length + " letters");
    }
}
````

## Aufgabe 2: Zerlegen und Zusammensetzen von Zeichenketten
<br>

**Gegeben seien zwei Strings** `s1` und `s2` sowie zwei Arrays `a1` und `a2`. 
  - Welche Java-Anweisung
    vergleicht `s1` und `s2` bzw. `a1` und `a2` auf Gleichheit? 
  - Welche Anweisung vergleicht auf Identität?
 
<br>

**Gegeben ist folgende Methoden-Signatur:**

```java
public static String[] string2StringArray(String s) 
```

Implementieren Sie diese Methode in einer Klasse `StringUtil`, die den String `s` in seine Einzelwörter zerlegt. Diese sollen dann alphabetisch sortiert in einem Array von Strings eingetragen und zurückgeliefert werden.
  - Bsp.: Die Eingabe „bald sind Ferien“ liefert das String-Array („bald“, „Ferien“, sind“). 
  - Hinweise:
      - Die Java-Klasse Arrays liefert eine einfache Möglichkeit, ein Array von Strings zu sortieren.
        https://docs.oracle.com/javase/8/docs/api/java/util/Arrays.html
      - Informieren Sie sich über die Methode `split` der Klasse String und über reguläre Ausdrücke:
          - https://docs.oracle.com/javase/8/docs/api/java/lang/String.html
          - https://docs.oracle.com/javase/8/docs/api/java/util/regex/Pattern.html
      - Als Trennzeichen für Einzelwörter fungieren ein oder mehrere aufeinanderfolgende White-
        spaces.


<br>

**Gegeben ist folgende Methoden-Signatur:**
````java
public static String stringArray2String(String[] arr)
````
Implementieren Sie diese Methode, die Elemente eines String-Arrays zu einem langen String (mit Trennzeichen ' ') zusammenfügt.
  - Verwenden Sie hierzu die Klasse `StringBuffer`.
  - Verwenden Sie **nicht** `Arrays.toString()` oder die Methode `join()` der Klasse `String`.

<br>

**Implementieren Sie eine JUnit5 Testklasse `StringUtilsTest`**, die Folgendes testet:
* „kurt fährt auto“ soll gemäß `b)` korrekt in das Array `[„auto“, „fährt“, „kurt“]` zerlegt werden.
* „kurt fährt auto“ soll trotz der vielen Whitespaces in das gleiche Array zerlegt werden.
* Das Array `[„kurt“, „fährt“, „Auto“]` ergibt beim Zusammensetzen gemäß `c)` „kurt fährt Auto“. 
* Die Methode `assertArrayEquals(.)` kann nützlich sein.

## Aufgabe 3: Anagramme

Der Begriff Anagramm bezeichnet eine Buchstabenfolge, die aus einer anderen Buchstabenfolge allein
durch Umstellung (Permutation) der einzelnen Buchstaben gebildet wird. Beispielsweise sind „Bier“ und
„Brei“ ein Anagramm. Ebenso sind „Fr. Inge C. Sonst, Rheine“ und „Schornsteinfegerin“ Anagramme.
Wir betrachten im Folgenden nur Buchstaben und ignorieren Sonderzeichen, Ziffern, Leerzeichen sowie
Groß- und Kleinschreibung.

- Gegeben ist folgende Methoden-Signatur:
````java
public static boolean areAnagrams(String string1,String string2)
````
  - Implementieren Sie diese Methode, die prüft ob zwei Strings Anagramme sind. 
  - Hinweise:
    - Sie können mit `Character.isLetter(char c)` einen Character überprüfen.
    - Nützliche Funktionen finden Sie ggfs. auch in der Klasse `Arrays` und `StringBuilder`.

- Erweitern Sie die JUnit5 Testklasse `StringUtilsTest` mit folgenden Tests:
    - „Debit Card“ und „Bad Credit“ sind Anagramme.
    - „derbe Hotline“ und „Bohlen, Dieter“ sind Anagramme.
    - „Haus“ und „Haus“ sind keine Anagramme, da es sich um die gleichen Wörter handelt.
    - „joy“ und „enjoy“ sind ebenfalls keine Anagramme.

## [Optional] Aufgabe 4: Palindrome Checker
Ein **Palindrom** ist ein Wort oder ein Satz, der - ohne Berücksichtigung von Sonderzeichen/Groß-/Kleinschreibung - vorwärts und rückwärts gelesen identisch ist, z. B:

- „Otto“
- „Risotto, Sir?“
- "Do geese see God?"

Implementieren und testen Sie in `StringUtil`:
1. Schreiben Sie eine statische Methode `filter()` für die Klasse, die alle Nicht-Buchstaben in einer angegebenen Zeichenkette eliminiert, alle anderen Zeichen in Kleinbuchstaben umwandelt und dann die erzeugte Zeichenkette als Ergebnis zurückgibt.
2. Schreiben Sie eine weitere statische Methode `isPalindrome()`, die überprüft, ob die übergebene Zeichenkette ein Palindrom ist. Wenn ja, gibt die Methode `true` zurück. 
3. Erweitern Sie `StringUtilTest`, um die in (a) und (b) implementierten Methoden entsprechend testet. Verwenden Sie parametrisierte Tests! Eine Testsequenz könnte wie folgt aussehen:
```console
Otto filtered: otto
 -> is palindrome: true
Blaukraut bleibt Blaukraut und Brautkleid bleibt Brautkleid filtered: blaukrautbleibtblaukrautundbrautkleidbleibtbrautkleid
 -> is palindrome: false
Risotto, Sir? filtered: risottosir
 -> is palindrome: true
Ein Esel lese nie. filtered: einesellesenie
 -> is palindrome: true
Vitaler Nebel mit Sinn ist im Leben relativ! filtered: vitalernebelmitsinnistimlebenrelativ
 -> is palindrome: true
Madam filtered: madam
 -> is palindrome: true
level filtered: level
 -> is palindrome: true
A Santa lived as a devil at NASA filtered: asantalivedasadevilatnasa
 -> is palindrome: true
Was it a car or a cat I saw? filtered: wasitacaroracatisaw
 -> is palindrome: true
Eva, can I see bees in a cave? filtered: evacaniseebeesinacave
 -> is palindrome: true
Never odd or even filtered: neveroddoreven
 -> is palindrome: true
```

**Hinweise:**
- Sie können alle Methoden der Klasse `java.lang.Character` und alle Methoden der Klasse `java.lang.String` zur Implementierung verwenden.
- Alle Vorschläge für englische Palindrome zum Testen sind willkommen ;-)

## Hilfestellungen

* java.util.Arrays: https://docs.oracle.com/javase/7/docs/api/java/util/Arrays.html  
* java.lang.System: https://docs.oracle.com/javase/7/docs/api/java/lang/System.html  
* java.lang.Character: https://docs.oracle.com/javase/7/docs/api/java/lang/Character.html  
* java.lang.String: https://docs.oracle.com/javase/7/docs/api/java/lang/String.html  
* java.util.regex.Pattern: https://docs.oracle.com/javase/7/docs/api/java/util/regex/Pattern.html  
* java.lang.StringBuffer: https://docs.oracle.com/javase/7/docs/api/java/lang/StringBuffer.html
package oop.th.rosenheim;

import org.junit.jupiter.api.Test;

class RationalTest {

	@Test
	void testDefaultConstructorCreatesZeroRational() {
	}
}
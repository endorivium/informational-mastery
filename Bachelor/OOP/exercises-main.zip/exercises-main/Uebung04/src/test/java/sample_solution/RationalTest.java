package sample_solution;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RationalTest {

	@Test
	void testDefaultConstructorCreatesZeroRational() {
		Rational r = new Rational();
		assertEquals(0, r.getNumerator());
		assertEquals(1, r.getDenominator());
	}

	@Test
	void testConstructorWithNumeratorAndDenominator() {
		Rational r = new Rational(3, 4);
		assertEquals(3, r.getNumerator());
		assertEquals(4, r.getDenominator());
	}

	@Test
	void testConstructorWithDoubleValue() {
		Rational r = new Rational(0.75);
		assertEquals(3, r.getNumerator());
		assertEquals(4, r.getDenominator());
	}

	@Test
	void testConstructorWithStringValue() {
		Rational r = new Rational("3/4");
		assertEquals(3, r.getNumerator());
		assertEquals(4, r.getDenominator());
	}

	@Test
	void testAddTwoRationals() {
		Rational r1 = new Rational(1, 2);
		Rational r2 = new Rational(1, 3);
		Rational result = r1.add(r2);
		assertEquals(5, result.getNumerator());
		assertEquals(6, result.getDenominator());
	}

	@Test
	void testSubtractTwoRationals() {
		Rational r1 = new Rational(1, 2);
		Rational r2 = new Rational(1, 3);
		Rational result = r1.subtract(r2);
		assertEquals(1, result.getNumerator());
		assertEquals(6, result.getDenominator());
	}
}
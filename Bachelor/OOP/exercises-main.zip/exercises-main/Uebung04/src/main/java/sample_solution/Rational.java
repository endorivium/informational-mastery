package sample_solution;

/**
 * Die Klasse Rational zum Darstellen von rationalen Zahlen
 *
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified 				  Breunig/Hüttl/Deubler ...
 * Modified 	    7.4.2017, Wolfgang Mühlbauer
 * Modified	        21.4.2025, Silke Lechner-Greite
 */

public final class Rational {

    // Konstanten
    public static final String DELIMITER = "/";       // "Bruchstrich"
    private static final long PRECISION = 10000000L;  // definiert Anzahl Nachkommastellen bei "double"

    // Klassenattribute
    private final long numerator;     // zaehler
    private final long denominator;   // nenner


    /**
     * Ermittlung des größten gemeinsamen Teilers (GCD = greatest common devisor)
     *
     * @param a (positive) ganze Zahl
     * @param b (positive) ganze Zahl
     * @return größter gemeinsamer Teiler
     */
    private static long gcd(long a, long b) {
        a = Math.abs(a);
        b = Math.abs(b);
        if (a < b)
            return gcd(b, a);
        if (b == 0)
            return a; // Null wird von jeder Zahl geteilt
        long c = 1;
        while (c != 0) {
            c = a % b;
            a = b;
            b = c;
        }
        return a;
    }

    /** Rekursive Variante:
     * private static long gcd(long a, long b) {
     *     a = Math.abs(a);
     *     b = Math.abs(b);
     *     if (b == 0) {
     *         return a;
     *     }
     *     return gcd(b, a % b);
     * }
     */

    // Konstruktoren

    /**
     * Erzeugt Bruch "num"/"den" mit Zähler und Nenner vom Typ long
     *
     * @param numerator Zähler
     * @param denominator Nenner
     */
    public Rational(long numerator, long denominator) {

        // Hier passiert die Normierung (vorher: norm())
        long gcd = gcd(numerator, denominator);
        numerator /= gcd;
        denominator /= gcd;

        if (denominator < 0) {  // Nenner positiv machen
            numerator = -numerator;
            denominator = -denominator;
        }
        this.numerator = numerator;
        this.denominator = denominator;
    }

    /**
     * Erzeugt Bruch mit Wert 0, d.h. 0/1
     */
    public Rational() {
        this(0,1);
    }

    /**
     * Erzeugt ganzzahligen Bruch "val"/1. (=Bruchdarstellung von ganzen Zahlen)
     *
     * @param val long
     */
    public Rational(long val) {
        this(val, 1);
    }

    /**
     * Erzeugt Bruch von einem double Wert
     *
     * @param val double-Wert
     */
    public Rational(double val) {
        this((long) (val * PRECISION), PRECISION);
    }

    /**
     * Erzeugt Bruch aus String der Form "x/y"
     *
     * @param val String
     */
    public Rational(String val) {
        this(Long.parseLong(val.trim().split(DELIMITER)[0]),
                Long.parseLong(val.trim().split(DELIMITER)[1]));

    }

    // getter-Methoden

    /**
     * gibt den privaten Zähler
     *
     * @return Zähler
     */
    public long getNumerator() {
        return numerator;
    }

    /**
     * gibt den privaten Nenner
     *
     * @return Nenner
     */
    public long getDenominator() {
        return denominator;
    }

    // einfache Umwandlungen

    /**
     * Gibt die Rationalzahl als double zurück, indem der Zähler durch den Nenner dividiert wird.
     *
     * @return die Rationalzahl als Double
     */
    public double doubleValue() {
        return ((double) numerator) / denominator;
    }

    /**
     * Ermittlung der Stringdarstellung
     *
     * @return eine Stringdarstellung der Rationalzahl der Form "a/b"
     */
    @Override
    public String toString() {
        return numerator+DELIMITER+denominator;
    }

    /**
     * Negation = Multiplikation mit -1
     *
     * @return den negativen Bruch
     */
    public Rational negate() {
        return new Rational(-numerator, denominator);
    }

    /**
     * Kehrbruch
     *
     * @return den Kehrbruch (aus a/b wird b/a)
     */
    public Rational invert() {
        return new Rational(denominator, numerator);
    }

    // Bruchrechnen

    /**
     * Zwei Brüche (a,b) werden addiert. Dazu wird der Bruch erweitert
     *
     * @param val der Bruch (b), welcher addiert werden soll.
     * @return Eine neue Rationalzahl als Ergebnis der Operation
     */
    public Rational add(Rational val) {
        return new Rational(
                this.numerator * val.denominator + val.numerator * this.denominator,
                this.denominator * val.denominator);
        // die Normierung erfolgt im Konstruktor
    }

    /**
     * Zieht von einem Bruch einen anderen ab (a-b) indem mit dem negierten Bruch
     * addiert wird (a+(-b)). Diese Methode ist ein Beispiel für gute, wenig redundante Programmierung,
     * indem die subtract-Methode auf eine bestehende Methode abgebildet wird, ohne die Logik
     * erneut zu programmieren.
     *
     * @param val der Bruch (b), der abgezogen wird
     * @return Eine neue Rationalzahl als Ergebnis der Operation
     */
    public Rational subtract(Rational val) {
        return add(val.negate());
    }

    /**
     * Multipliziert zwei Brüche (a,b)
     *
     * @param val der Bruch (b)
     * @return Eine neue Rationalzahl als Ergebnis der Operation
     */
    public Rational multiply(Rational val) {
        return new Rational(
                this.numerator * val.numerator,
                this.denominator * val.denominator);
    }

    /**
     * Teilt einen Bruch durch einen anderen, indem mit dem Kehrbruch multipliziert wird.
     *
     * @param val der Bruch durch den geteilt wird.
     * @return Eine neue Rationalzahl als Ergebnis der Operation
     */
    public Rational divide(Rational val) {
        return multiply(val.invert());
    }
}
# Übung 04 : Brüche als Objekte

" ... Eine rationale Zahl ist eine reelle Zahl, die als Verhältnis (lateinisch ratio) zweier ganzer Zahlen dargestellt werden kann. ..." ( [Wikipedia](https://de.wikipedia.org/wiki/Rationale_Zahl) ). Dies wollen wir als eigenen Datentypen mit Java realisieren.

## Kernthemen
- Überladen von Konstruktoren und Methoden
- Objekte als Parameter bzw. als Rückgabetyp einer Methode
- Unveränderliche Klassen und Objekte (immutable)

## Aufgabe 1: Klasse Rational
Implementieren Sie die Klasse [Rational](src/main/java/oop/th/rosenheim/Rational.java) an den dafür vorgesehenen Stellen (`//ToDo`). Jede Instanz der Klasse soll einen Bruch bestehend aus Zähler und Nenner repräsentieren. Die Klasse `Rational` soll unveränderlich („immutable“) sein. Die Methoden `negate`, `invert`, `add`, `subtract`, `multiply`, `divide` lassen die Aufrufparameter unverändert und erzeugen als Ergebnis immer neue Objekte. Intern soll ein Bruch immer im vollständig gekürzten Zustand gespeichert sein.

## Aufgabe 2: Test
- Testen Sie Ihr Programm mit der main-Methode von [Test.java](src/main/java/oop/th/rosenheim/Test.java). Innerhalb dieser Methode werden
einige einfache Brüche erzeugt bzw. einfache Berechnungen durchgeführt. 
- Sollte eine Berechnung
falsch sein, so gibt es auf der Standardausgabe eine entsprechende Fehlermeldung.

## Hilfestellungen

- Beachten Sie, dass es verschiedene Möglichkeiten gibt, einen Bruch darzustellen. Zum Beispiel
  handelt es sich bei 1/2 und 2/4 mathematisch um den gleichen Wert. Intern soll ein Bruch deshalb
  immer im vollständig gekürzten Zustand gespeichert sein (also 1/2). 
- Ferner soll der Nenner immer positiv sein. Dies wird durch die Methode `norm()` erreicht. Verwenden Sie für `norm()` die bereits vorgegebene Methode `gcd(long a, long b)`, die
  den größten gemeinsamen Teiler aus zwei Zahlen `a` und `b` berechnet.
- Verwenden Sie im Konstruktor `Rational(String val)` die Klasse `Scanner` mit dem Delimiter `/`,
  um aus einem String `x/y` Zähler `x` und Nenner `y` zu ermitteln.
- Verwenden Sie so weit möglich bestehende Methoden. Beispielsweise lässt sich eine Division
  von Brüchen auf eine Multiplikation von Brüchen zurückführen.
- Verwenden Sie zur Fehlersuche den Debugger.

## Brüche

```
Addition von Brüchen: Wenn zwei Brüche verschiedene Nenner haben, müssen sie zuerst auf denselben Nenner gebracht werden:
a/b + c/d = (a*d + b*c) / (b*d)
Beispiel: 1/3 + 1/4 = (1*4 + 1*3) / (3*4) = (4 + 3) / 12 = 7/12

Subtraktion von Brüchen: Analog zur Addition
a/b - c/d = (a*d - b*c) / (b*d)
Beispiel: 3/4 - 1/6 = (3*6 - 4*1) / (4*6) = (18 - 4) / 24 = 14/24 = 7/12

Multiplikation von Brüchen: Einfach Zähler mal Zähler und Nenner mal Nenner:
a/b * c/d = (a * c) / (b * d)
Beispiel: 2/3 * 4/5 = (2*4) / (3*5) = 8/15


Division von Brüchen: Bei der Division wird mit dem Kehrwert des zweiten Bruchs multipliziert:
a/b / c/d
Beispiel: 2/3 ÷ 4/5 = (2*5) / (3*4) = 10/12 = 5/6

```

## [Optional:]
- Implementieren Sie die Tests, die in `Test.java` gegeben sind, mit JUnit in der Klasse [RationalTest](src/test/java/oop/th/rosenheim/RationalTest.java) .


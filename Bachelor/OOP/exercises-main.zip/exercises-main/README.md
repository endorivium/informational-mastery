# OOP-Uebungen

## Quick-links
- [Übung 1: Installation](Uebung01)
- [Übung 2: Prozedural: Game of Life](Uebung02)
- [Übung 3: Klassen und Objekte](Uebung03)
- [Übung 4: Brüche als Objekte](Uebung04)
- [Übung 5: Vernetzung von Objekten](Uebung05)
- [Übung 6: Warteschlangen und Junit](Uebung06)
- [Übung 7: Vererbung: Geometrische Formen](Uebung07)
- [Übung 8: Vererbung: Abstrakte Klassen](Uebung08)
- [Übung 9: Modellierung mit UML](Uebung09)
- [Übung 10: Character und String Klassen](Uebung10)
- [Übung 11: Objektmethoden überschreiben, Objekte Vergleichen und Ordnen, Iterieren](Uebung11)
- [Übung 12: Generics und Collections](Uebung12)
- [Übung 13: Exceptions](Uebung13)

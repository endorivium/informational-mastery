package sample_solution;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import sample_solution.task2.Circle;
import sample_solution.task2.Rectangle;
import sample_solution.task2.Shape;
import sample_solution.task2.Square;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Junit5 Tester to test Shape inheritance structure
 *
 * @author  	Professoren und Tutoren der Informatikfakultät
 * @version     2.0<br>
 * Modified 	    12.5.2017, Wolfgang Mühlbauer<br>
 * Adapted to Junit5  4.4.2020, Silke Lechner-Greite<br>
 * Modified     6.3.2021, Bernd Weiss
 *
 */

@DisplayName("Shape tests:")
class ShapeTest {

    @Test
    @DisplayName("Circle test")
    void testCircle() {
        Circle c1 = new Circle(2);

        assertEquals(12.6, c1.getArea(), 0.1, "area");
        assertEquals(12.6, c1.getPerimeter(), 0.1, "perimeter");
        assertEquals(c1.getArea(), c1.getPerimeter(), "perimeter");
    }

    @Test
    @DisplayName("Rectangle test")
    void testRectangle() {
        Rectangle r1 = new Rectangle(5, 4);

        assertEquals(20, r1.getArea(), "area");
        assertEquals(18, r1.getPerimeter(), "perimeter");
    }

    @Test
    @DisplayName("Square test")
    void testSquare() {
        Square s1 = new Square(5);

        assertEquals(25, s1.getArea(), "area");
        assertEquals(20, s1.getPerimeter(), "perimeter");

        s1.setLength(6);
        assertEquals(6, s1.getLength(), "side with setLength");
        assertEquals(6, s1.getWidth(),"side with setLength");

        s1.setWidth(7);
        assertEquals(7, s1.getWidth(),"side with setWidth");
        assertEquals(7, s1.getLength(),"side with setWidth");
    }

    @Test
    @DisplayName("Polymorphism test")
    void testPolymorphism() {

        Shape shape = new Shape("blue");
        Circle circle = new Circle(2, "Blue");
        Rectangle rectangle = new Rectangle(3, 5, "Orange");
        Square square = new Square(1.0, "green");

        assertTrue(circle instanceof Shape);
        assertTrue(rectangle instanceof Shape);
        assertTrue(square instanceof  Shape);

        Shape[] shapes = {shape, circle, rectangle, shape};

        for (Shape s : shapes)
            System.out.println(s);

    }

}
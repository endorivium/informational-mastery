package oop.th.rosenheim;

public class ShapeTest {
}

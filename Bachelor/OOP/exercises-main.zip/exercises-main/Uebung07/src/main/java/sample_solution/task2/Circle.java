package sample_solution.task2;
/**
 * Klasse Circle erbt von Shape
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created      11.5.2017 Wolfgang Mühlbauer
 * Modified 	4.4.2020, Silke Lechner-Greite
 */
public class Circle extends Shape {

    final private double radius; // nach Initialisierung nicht mehr änderbar

    /**
     * Value constructor 1
     * @param radius
     */
    public Circle(double radius) {
        this.radius = radius;  // Here: super not mandatory due to existence of default constructor in super class
    }

    /**
     * Value constructor 2
     * @param radius
     * @param color
     */
    public Circle(double radius, String color) {
        super(color);
        this.radius = radius;
    }

    /**
     * getter for radius
     * @return radius
     */
    public double getRadius() {
        return radius;
    }

    /**
     * calculates area of circle
     * @return area
     */
    public double getArea() {
        return radius * radius * Math.PI;
    }

    /**
     * calculates perimeter of circle
     * @return perimeter
     */
    public double getPerimeter() {
        return 2 * radius * Math.PI;
    }

    /**
     * override toString method
     * @return string
     */
    //@Override
    public String toString() {
        return "Circle(radius=" + radius + "), subclass of " + super.toString();
    }
}

package sample_solution.task1;

/**
 * Testprogramm: welche Vererbungsstatements funktionieren?
 *
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created 	    4.4.2020, Silke Lechner-Greite
 */



public class Task1 {

    /**
     * main-Methode welche das Javaprogramm ausführt.
     * @param args input param - String array
     */
    public static void main(String[] args) {



        BaseClass base = new BaseClass();
        DerivedClass derived = new DerivedClass();


        base = derived;  // zulässig
        //derived = base;  // unzulässig - u ist Spezialisierung von o
        derived = (DerivedClass) base;
        //u = new Oberklasse(); // unzulässig, siehe b)
        derived = (DerivedClass) new BaseClass();
        base = new DerivedClass();  // zulässig
        BaseClass baseClass1 = derived; DerivedClass derivedClass1 = (DerivedClass) baseClass1; // erster Teil: zulässig, zweiter Teil: unzulässig
        DerivedClass derivedClass2 = derived; BaseClass baseClass2 = derivedClass2; // erster Teil: zulässig, zweiter Teil: zulässig
    }
}

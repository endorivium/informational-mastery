package sample_solution.task1;
/**
 * Leere Dummy-Klasse
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created 	    4.4.2020, Silke Lechner-Greite
 */
public class BaseClass {



}

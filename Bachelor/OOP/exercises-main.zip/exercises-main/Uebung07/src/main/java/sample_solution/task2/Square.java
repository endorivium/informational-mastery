package sample_solution.task2;
/**
 * Klasse Square erbt von Rectangle
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created      11.5.2017 Wolfgang Mühlbauer
 * Modified 	4.4.2020, Silke Lechner-Greite
 */
public class Square extends Rectangle {

    /**
     * Value constructor 1
     * @param side
     */
    public Square(double side) {
        super(side, side);
    }

    /**
     * Value constructor 2
     * @param side
     * @param color
     */
    public Square(double side, String color) {
        super(side, side, color);
    }

    /**
     * getter width
     * @return width
     */
    public double getSide() {

        return super.width;
        // or just return width
        // this.getLength();
        // super.getLength(); (im Falle dass Length private ist, und nicht protected.
    }

    /**
     * setter for width and length
     * @param side
     */
    public void setSide(double side) {
        super.width = side;  // or just width = side
        super.length = side; // both
    }


    /**
     * Override setWidth from superclass
     * @param side
     */
    //@Override
    public void setWidth(double side) {
        super.width = side;  // or just width = side
        super.length = side;
    }

    /**
     * override setWidth from superclass
     * @param length
     */
    //@Override
    public void setLength(double length) {
        super.width = length;  // or just width = side
        super.length = length;
    }

    /**
     * override toString method
     * @return string
     */
    //@Override
    public String toString() {
        return "A Square with side " + width + ", subclass of " + super.toString();
    }
}

package sample_solution.task2;
/**
 * Klasse Shape
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created      11.5.2017 Wolfgang Mühlbauer
 * Modified 	4.4.2020, Silke Lechner-Greite
 */
public class Shape {

    // class attributes
    private String color;
    final private double lineWidth;    // dt. "Linienstärke"

    /**
     * Constructor with empty parameter list
     */
    public Shape() {
        lineWidth = Math.random() * Math.random();
        color = "red";
    }

    /**
     * Value Constructor
     * @param color
     */
    public Shape(String color) {
        this();                  // call default constructor
        this.color = color;
    }

    /**
     * getter for color
     * @return color
     */
    public String getColor() {
        return color;
    }

    /**
     * override toString method as given in exercise
     * @return string
     */
    //@Override
    public String toString() {
        String temp = "Shape(color=" + color +", line_width=" + lineWidth + ")";
        return temp;
    }

}

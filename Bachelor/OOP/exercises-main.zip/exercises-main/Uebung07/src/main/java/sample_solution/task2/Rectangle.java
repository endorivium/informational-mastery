package sample_solution.task2;
/**
 * Klasse Rectangle erbt von Shape
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created      11.5.2017 Wolfgang Mühlbauer
 * Modified 	4.4.2020, Silke Lechner-Greite
 */
public class Rectangle extends Shape {

    // class attributes
    protected double width;
    protected double length;

    /**
     * Value constructor 1
     * @param width
     * @param length
     */
    public Rectangle(double width, double length) {
        super();
        this.width = width;
        this.length = length;
    }
    /**
     * Value constructor 2
     * @param width
     * @param length
     * @param color
     */
    public Rectangle(double width, double length, String color) {
        super(color);
        this.width = width;
        this.length = length;
    }

    /**
     * getter for width
     * @return width
     */
    public double getWidth() {
        return width;
    }

    /**
     * getter for length
     * @return length
     */
      public double getLength() {
        return length;
    }

    /**
     * setter for width
     * @param width
     */
    public void setWidth(double width) {
        this.width = width;
    }

    /**
     * setter for length
     * @param length
     */
    public void setLength(double length) {
        this.length = length;
    }

    /**
     * calculate area of rectangle
     * @return area
     */
    public double getArea() {
        return width * length;
    }

    /**
     * calculate perimeter of rectangle
     * @return perimeter
     */
    public double getPerimeter() {
        return (2 * width + 2 * length);
    }

    /**
     * override toString method
     * @return string
     */
    @Override
    public String toString() {
        return "Rectangle(width=" + width + ", length=" + length + "), subclass of " + super.toString();
    }
}



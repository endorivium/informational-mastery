# Übung 07 Vererbung
In dieser Übung beschäftigen wir uns mit dem Thema der Vererbung und setzen dies anhand des Klassikers um, den geometrischen Figuren.

## Kernthemen
- Substitutionsprinzip und Polymorphismus
- Entwerfen/Implementieren von Vererbungsstrukturen
- Verwenden des Schlüsselwortes „super“
- Überschreiben von Methoden der Oberklasse
- Testing mit JUnit5

## Aufgabe 01: Liskovsches Substitutionsprinzip
"... Es besagt, dass ein Programm, das Objekte einer Basisklasse T verwendet, auch mit Objekten der davon abgeleiteten Klasse S korrekt funktionieren muss, ohne dabei das Programm zu verändern. ... " ( [Wikipedia](https://de.wikipedia.org/wiki/Liskovsches_Substitutionsprinzip) )

Gegeben sei eine `BaseClass` `base`.  
Eine `DerivedClass` erbt von `BaseClass`.  
Welche der nachfolgenden Ausdrücke a) bis f) sind im Anschluss an die beiden ersten Codezeilen erlaubt, welche nicht? Begründen Sie Ihre Antwort!  

````java
public class Task1{

    BaseClass base = new BaseClass();
    DerivedClass derived = new DerivedClass();

    base = derived;  // a
    derived = base;  // b
    derived = new BaseClass(); // c
    base = new DerivedClass();  // d
    BaseClass base1 = derived; DerivedClass derived1 = base1; // e
    DerivedClass derived2 = derived; BaseClass base2 = derived2; // f
} 
````

Können Sie mithilfe eines Typecasts eines der Statements korrigieren, so dass der Compiler keinen Alarm schlägt?

## Aufgabe 2: Geometrische Formen
In der folgenden Aufgabe sollen Vererbungskonzepte in Java an einem kleinen Beispiel erprobt werden. Die folgende Abbildung zeigt die zu implementierenden Klassen.

![Klassendiagramm](Hilfestellungen/Klassendiagramm.png)

Im Klassendiagramm sind noch keine Sichtbarkeiten eingetragen, ebenso fehlen die Beziehungen (Assoziation, Vererbung) zwischen den Klassen.

- Überlegen Sie sich, wie sie die vier Klassen in einer Vererbungshierarchie anordnen können! Fertigen Sie ggfs. ein neues UML Klassendiagramm an.
- Implementieren Sie alle vier Klassen unter Beachtung der folgenden Vorgaben:
  - Die `toString()`-Methode gibt jeweils die typischen Merkmale einer Klasse als `String` zurück. 
    - Beispiel Rechteck:
      - `Rectangle(width=1.0, length=2.0) is a Shape(color=blue, line_width=0.82)`
      - Bei einer abgeleiteten Klasse sollen also auch die Merkmale der Oberklasse und deren Typ zurückgegeben werden. 
      - Wie löst man das elegant?
  - Die Linienstärke (`lineWidth`) einer Form (`Shape`) ist eine Zufallszahl aus dem Intervall `[0; 2[`.
  - Verwenden Sie Sichtbarkeiten (private, public, etc.).
  - Vermeiden Sie Code-Redundanz so gut wie möglich.
  - Alle Klassen sollen so gut wie möglich unveränderliche Attribute haben. Beachten Sie aber, dass von jeder Klasse eine Unterklasse abgeleitet werden darf und bei den Klassen `Rectangle` und `Square` „Setter“ erlaubt sind.
  - Überschreiben Sie ggfs. Funktionen in den Unterklassen, z.B. `setWidth()` und `setLength()` in `Square`. 
  - Verwenden Sie die Annotation `@Override`.
  - Konstanten und mathematische Funktionen finden Sie in der Klasse Math:
    https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html

**Hinweis:**
- Schauen Sie sich die Vererbungshierarchie in IntelliJ durch Ctrl + h an


## Aufgabe 3: JUnit Tests der Vererbungsstruktur
Natürlich testen Sie wieder Ihren erzeugten Code:

Implementieren Sie in einer JUnit5 Klasse die folgenden drei Tests:
  - Die Fläche eines Kreises mit Radius 2 beträgt ca. 12,6. 
    - Hinweis: Ändert man mit der Methode `setLength()` die Länge eines Quadrats (`Square`), so ist danach das Attribut `length` der Oberklasse gleich dem Attribut `width` der Oberklasse.
  - Bauen Sie ein Array aus vier Elementen mit einem `Circle`, einem `Square`, einem `Rectangle` und einer allgemeinen geometrischen Form (`Shape`). 
  - Iterieren Sie dann über das Array und geben Sie dabei
    die Merkmale aller Objekte auf der Konsole aus.
  - Warum funktioniert das?
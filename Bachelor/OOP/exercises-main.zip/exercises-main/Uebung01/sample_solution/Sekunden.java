
import java.util.Scanner;

/**
 * Einfaches Programm mit Ein-/Ausgabe (wie bei C) mit Javadoc.
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created on 	    12.3.2010 / 2016, Breunig / Mühlbauer
 * Modified	        20.3.2020, Silke Lechner-Greite
 */


public class Sekunden {

    /**
     * Finale, statische Variablen
     */
    private final static int SEKUNDEN_PRO_MINUTE = 60;
    private final static int MINUTEN_PRO_STUNDE = 60;

    /** Main Methode zum Ausfuehren des Programms. "throws" und
     * Exceptions werden spaeter in der Vorlesung behandelt
     * und sind deswegen auskommentiert.
     * @param args Eingabeparameter - String array
     */
    public static void main(String[] args)
    // throws NumberFormatException, IOException
    {
        int sekunden, minuten, stunden;

        // Eingabe mit Scanner
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bitte Stunden eingeben: ");
        stunden = scanner.nextInt();
        System.out.println("Bitte Minuten eingeben: ");
        minuten = scanner.nextInt();
        // Sekunden berechnen
        sekunden = ((stunden * MINUTEN_PRO_STUNDE) + minuten) * SEKUNDEN_PRO_MINUTE;

        // und ausgeben
        System.out.println(stunden + " Stunden und " + minuten + " Minuten sind " + sekunden + " Sekunden.");
    }
}

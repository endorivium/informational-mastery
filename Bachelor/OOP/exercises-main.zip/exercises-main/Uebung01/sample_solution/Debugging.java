/**
 * Java class to practice debugging.
 * @author Professoren der Informatikfakultät
 * @version 1.0
 * Created on 	    13.3.2017, Wolfgang Mühlbauer
 * Modified	        20.3.2020, Silke Lechner-Greite
 */
public class Debugging {
    /**
     * main-Methode welche das Javaprogramm ausführt.
     * @param args input param - String array
     */

    public static void main(String[] args) {
        int i3[] = {3, 4, 48, 0};

        int a = i3[2] - i3[1];
        int b = i3[1] * i3[2];
        int c = b / a;
        int d = b % a;
        b = ++c * a++ + d--;

        int[] output = new int[4];
        output[2] = b;
        System.out.println(output[2]);

        int[] test = new int[100];
        for (int i1 = 0; i1 < test.length; i1++) {
            int i = test[i1];

        }
    }
}
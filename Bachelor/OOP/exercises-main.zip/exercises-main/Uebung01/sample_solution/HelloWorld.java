
/**
 * Ein erstes Hallo Welt Programm.
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Created on 	    7.3.2016, Wolfgang Mühlbauer
 * Modified	        20.3.2020, Silke Lechner-Greite
 */

public class HelloWorld {
    /**
     * main-Methode welche das Javaprogramm ausführt.
     * @param args input param - String array
     */
    public static void main(String[] args) {

        System.out.println("Hallo Welt!");

        int[] input = {1, 2, 3, 4};
        int a = input[2] - input[0];
        int b = input[1] * input[2];
        int c = b % a;
        System.out.println(a +" "+ b+" "+ + c);

    }
}

/*
(1)
public class MeineKlasse {
    public static void main (String[] args) {
        System.out.println("Hello!");
    }
(2)
    public class MeineKlasse {
        public static void main (String[] args) {
            System.out.println("Hello"); System.out.println(" Welt!");
        }
    }

(3)
    public MeineKlasse
    {
        public static void main (String[] args)
        {
            System.out.println("Hello!");
        }
    }
(4)
    public class MeineKlasse
    {
        public static void main (String[] args);
        {
            System.out.println("Hello!");
        }
    }

*/
package sample_solution;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Junit5 Tester to test the tree structure
 *
 * @author  	Professoren und Tutoren der Informatikfakultät
 * @version     2.0<br>
 * Created 	    4.4.2020, Silke Lechner-Greite<br>
 * Modified     6.3.2021, Bernd Weiß
 * Modified     24.3.2025, Philipp Brünken
 */
@DisplayName("Boolean Operation Tests: ")
public class BooleanExpressionsTest {

    private BaseEvent trueEvent;
    private BaseEvent falseEvent;

    @BeforeEach
    void setUp() {
        trueEvent = new BaseEvent(true);
        falseEvent = new BaseEvent(false);
    }

    @Test
    @DisplayName("Test: BaseEvent")
    void testBaseEvents() {
        assertTrue(trueEvent.getValue());
        assertFalse(falseEvent.getValue());
    }

    @Test
    @DisplayName("Test: Or")
    void testOr() {
        assertTrue(new Or().addNode(trueEvent).getValue(), "1");
        assertTrue(new Or().addNode(trueEvent).addNode(trueEvent).getValue(), "1 | 1 = 1");
        assertTrue(new Or().addNode(trueEvent).addNode(falseEvent).getValue(), "1 | 0 = 1");
        assertTrue(new Or().addNode(falseEvent).addNode(trueEvent).getValue(), "0 | 1 = 1");
        assertFalse(new Or().addNode(falseEvent).addNode(falseEvent).getValue(), "0 | 0 = 0");

        Or or1 = new Or();
        for (int i = 0; i<1000; i++)
            or1.addNode(trueEvent);

        assertTrue(or1.getValue(), "1 | ... | 1 = 1");

        Or or2 = new Or();
        int random =  new Random().nextInt(1000);
        for (int i = 0; i<1000; i++) {
            if (i == random)
                or2.addNode(trueEvent);
            else
                or2.addNode(falseEvent);
        }

        assertTrue(or2.getValue(), "0 | ... | 0 | 1 | 0 | ... | 0 = 1");

        Or or3 = new Or();
        for (int i = 0; i<1000; i++)
            or3.addNode(falseEvent);

        assertFalse(or3.getValue(), "0 | ... | 0 = 0");
    }

    @Test
    @DisplayName("Test: And")
    void testOUnd() {
        assertTrue(new And().addNode(trueEvent).getValue(), "1");
        assertTrue(new And().addNode(trueEvent).addNode(trueEvent).getValue(), "1 & 1 = 1");
        assertFalse(new And().addNode(trueEvent).addNode(falseEvent).getValue(), "1 & 0 = 0");
        assertFalse(new And().addNode(falseEvent).addNode(trueEvent).getValue(), "0 & 1 = 0");
        assertFalse(new And().addNode(falseEvent).addNode(falseEvent).getValue(), "0 & 0 = 0");

        And and1 = new And();
        for (int i = 0; i<1000; i++)
            and1.addNode(trueEvent);

        assertTrue(and1.getValue(), "1 & ... & 1 = 1");

        And and2 = new And();
        int random =  new Random().nextInt(1000);
        for (int i = 0; i<1000; i++) {
            if (i == random)
                and2.addNode(trueEvent);
            else
                and2.addNode(falseEvent);
        }

        assertFalse(and2.getValue(), "1 & ... & 1 & 0 & 1 & ... & 0 = 0");

        And and3 = new And();
        for (int i = 0; i<1000; i++)
            and3.addNode(falseEvent);

        assertFalse(and3.getValue(), "0 & ... & 0 = 0");
    }

    @Test
    @DisplayName("Test: a AND (b OR c) / (a OR b) AND c")
    void testExpression1() {
        assertTrue(new And().addNode(trueEvent).addNode(new Or().addNode(trueEvent).addNode(trueEvent)).getValue(), "1 & (1 | 1) = 1");
        assertTrue(new And().addNode(trueEvent).addNode(new Or().addNode(falseEvent).addNode(trueEvent)).getValue(), "1 & (0 | 1) = 1");
        assertTrue(new And().addNode(trueEvent).addNode(new Or().addNode(trueEvent).addNode(falseEvent)).getValue(), "1 & (1 | 0) = 1");
        assertFalse(new And().addNode(trueEvent).addNode(new Or().addNode(falseEvent).addNode(falseEvent)).getValue(), "1 & (0 | 0) = 1");

        assertFalse(new And().addNode(falseEvent).addNode(new Or().addNode(trueEvent).addNode(trueEvent)).getValue(), "0 & (1 | 1) = 0");
        assertFalse(new And().addNode(falseEvent).addNode(new Or().addNode(falseEvent).addNode(trueEvent)).getValue(), "0 & (0 | 1) = 0");
        assertFalse(new And().addNode(falseEvent).addNode(new Or().addNode(trueEvent).addNode(falseEvent)).getValue(), "0 & (1 | 0) = 0");
        assertFalse(new And().addNode(falseEvent).addNode(new Or().addNode(falseEvent).addNode(falseEvent)).getValue(), "0 & (0 | 0) = 0");
    }

    @Test
    @DisplayName("Test: a OR (b AND c) / (a AND b) OR c")
    void testExpression2() {
        assertTrue(new Or().addNode(trueEvent).addNode(new And().addNode(trueEvent).addNode(trueEvent)).getValue(), "1 | (1 & 1) = 1");
        assertTrue(new Or().addNode(trueEvent).addNode(new And().addNode(falseEvent).addNode(trueEvent)).getValue(), "1 | (0 & 1) = 1");
        assertTrue(new Or().addNode(trueEvent).addNode(new And().addNode(trueEvent).addNode(falseEvent)).getValue(), "1 | (1 & 0) = 1");
        assertTrue(new Or().addNode(trueEvent).addNode(new And().addNode(falseEvent).addNode(falseEvent)).getValue(), "1 | (0 & 0) = 1");

        assertTrue(new Or().addNode(falseEvent).addNode(new And().addNode(trueEvent).addNode(trueEvent)).getValue(), "0 | (1 & 1) = 1");
        assertFalse(new Or().addNode(falseEvent).addNode(new And().addNode(falseEvent).addNode(trueEvent)).getValue(), "0 | (0 & 1) = 0");
        assertFalse(new Or().addNode(falseEvent).addNode(new And().addNode(trueEvent).addNode(falseEvent)).getValue(), "0 | (1 & 0) = 0");
        assertFalse(new Or().addNode(falseEvent).addNode(new And().addNode(falseEvent).addNode(falseEvent)).getValue(), "0 | (0 & 0) = 0");
    }
}

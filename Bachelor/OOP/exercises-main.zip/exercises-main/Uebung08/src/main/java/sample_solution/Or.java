package sample_solution;

/**
 * Klasse Oder erbt von ErweiterbarerKnoten
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified     4.4.2020 Silke Lechner-Greite
 */
public class Or extends ExtendableNode {
    /**
     * override die abstrakte Methode getValue
     * @return boolean
     */
    @Override
    public Boolean getValue() {
        Boolean erg=false;
        for(Node node :super.subNodes){
            erg=erg || node.getValue();
        }
        return erg;
    }
}

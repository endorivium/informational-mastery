package sample_solution;

/**
 * Unterklasse BaseEvent erbt von Node
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified     4.4.2020 Silke Lechner-Greite
 */
public class BaseEvent extends Node {
    // Objektattribut
    protected Boolean value;

    /**
     * Value constructor
     * @param value
     */
    public BaseEvent(Boolean value) {
        this.value=value;
    }

    /**
     * setter for Wert
     * @param value
     */
    public void setValue(Boolean value){
        this.value=value;
    }

    /**
     * Implementation of abstract method getWert
     * @return boolean
     */
    @Override
    public Boolean getValue() {
        return value;
    }
}

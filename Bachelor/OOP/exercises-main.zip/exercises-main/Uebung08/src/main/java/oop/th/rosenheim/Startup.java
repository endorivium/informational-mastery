package oop.th.rosenheim;

/**
 * Ausführendes Programm für Übung 8
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified     4.4.2020 Silke Lechner-Greite
 */
public class Startup {

    public static void main(String[] args) {

        BaseEvent a = new BaseEvent(true);
        BaseEvent b = new BaseEvent(false);
        BaseEvent c = new BaseEvent(true);

        Or tree = new Or();
        tree.addNode(a).addNode(new And().addNode(b).addNode(c));
        System.out.println(tree);

    }
}

package sample_solution;

/**
 * Abstrakte Oberklasse Knoten
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified     4.4.2020 Silke Lechner-Greite
 */
public abstract class Node {
    /**
     * Abstrakte Methode getWert()
     * @return boolean
     */
    public abstract Boolean getValue();

    @Override
    public String toString(){
        if(getValue()){
            return "1";
        }else{
            return "0";
        }
    }
}
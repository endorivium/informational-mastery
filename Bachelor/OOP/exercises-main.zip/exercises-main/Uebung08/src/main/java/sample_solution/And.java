package sample_solution;

/**
 * Klasse Und erbt von ErweiterbarerKnoten
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified     4.4.2020 Silke Lechner-Greite
 */
public class And extends ExtendableNode {
    /**
     * override die abstrakte Methode getWert
     * @return boolean
     */
    @Override
    public Boolean getValue() {
        Boolean erg=true;
        for(Node node :super.subNodes){
            erg = erg && node.getValue();
        }
        return erg;
    }
}

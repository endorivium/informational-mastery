package sample_solution;

/**
 * Abstrakte Klasse ErweiterbarerKnoten erbt von Knote
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified     4.4.2020 Silke Lechner-Greite
 */

public abstract class ExtendableNode extends Node {

    // object members
    protected Node[] subNodes;

    /**
     * Constructor
     */
    public ExtendableNode() {
        this.subNodes =new Node[0];
    }

    /**
     * Method to add a "Knoten"
     * @param node
     * @return ErweiterbarerKnoten
     */
    public ExtendableNode addNode(Node node){
        Node[] newSubNodes = new Node[subNodes.length+1];
        for(int i = 0; i< subNodes.length; i++){
            newSubNodes[i]= subNodes[i];
        }
        newSubNodes[subNodes.length]= node;
        this.subNodes = newSubNodes;
        return this;
    }
}

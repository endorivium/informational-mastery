# Übung 08 Vererbung, abstrakte Klasse
In dieser Aufgabe implementieren Sie eine Datenstruktur die es erlaubt Boolesche Formeln als Bäume darzustellen.

## Kernthemen
- Implementierung einer Vererbungsstruktur
- Anwenden von abstrakten Klassen und Methoden
- „Dynamische“ Erweiterung eines Arrays
- Anwendung: Polymorphie

### Intro - Klasse `Node`
In Ihrer Implementierung werden Sie verschiedene Klassen von der gegebenen Oberklasse `Node` ableiten:

````java
public abstract class Node { 
    public abstract Boolean getValue();
    
    @Override
    public String toString(){
        if(getValue()){
            return "1";
        }else{
            return "0";
        }
    }
}
````

Wie sie sehen können, handelt es sich dabei um eine abstrakte Klasse. Diese können nicht instanziiert werden - es lassen sich keine Objekte mit `new` daraus erzeugen. 

Trotzdem können sie bereits Methoden und Attribute bereitstellen, die sich dann mittels Vererbung in anderen Klassen weiterverwenden lassen.

Außerdem ist es möglich abstrakte Methodenrümpfe vorzudefinieren,
die zwar hier keine Implementierung haben, aber von den Klassen implementiert werden müssen, die
von dieser abstrakten Klasse erben. 

Hier ist das z.B. die Methode `getValue()`. Klassen, die von `Node`
ableiten, sind entweder selber abstrakt oder müssen die Methode `getValue()` überschreiben.  

### Intro - Klasse `Startup`

````java
public class Startup {
  public static void main(String[] args) {

    BaseEvent a = new BaseEvent(true);
    BaseEvent b = new BaseEvent(false);
    BaseEvent c = new BaseEvent(true);

    Or tree = new Or();
    tree.addNode(a).addNode(new And().addNode(b).addNode(c));
    System.out.println(tree);
  }
}

````
Die Klasse Startup verwendet bereits die von Ihnen zu implementierende Datenstruktur. Hier wird
eine Boolesche Formel erzeugt `Tree = a OR ( b AND c )`.

### Aufgabe 1: Implementierung - Klasse `BaseEvent`
- Implementieren Sie zunächst die Klasse `BaseEvent` die von der Klasse `Node` erbt.
- Implementieren Sie zusätzliche Funktionalität so, dass ein Basisereignis den Wert true oder false annehmen kann.
### Aufgabe 2: Implementierung - Klasse `ExtendableNode`
- Implementieren Sie die abstrakte Klasse `ExtendableNode`, die die Klasse `Node` erweitert und die als Attribut ein Array von Knoten hat (`subNodes`) und eine Methode `addNode(Node node)`, bereitstellt mit Hilfe derer sich ein neuer Knoten zu den Unterknoten hinzufügen lässt. Diese Methode gibt ihr eigenes Objekt zurück, damit sie sich wie oben in `Startup` aufrufen lässt.

### Aufgabe 3: Implementierung - Klassen `Or` und `And`

- Implementieren Sie die Klasse `Or`, die von der Klasse `ExtendableNode` erbt. Überschreiben Sie die Methode `getValue()` so, dass eine logische Oder-Verknüpfung (Disjunktion) der Werte der Unterknoten entsteht.
- Implementieren Sie die Klasse `And` in ähnlicher Weise wie die Klasse `Or`. Überschreiben Sie die Methode `getValue()` so, dass eine logische Und-Verknüpfung (Konjunktion) der Werte der Unterknoten entsteht.

## Aufgabe 4: Testfälle 

- Implementieren Sie geeignete Testfälle für die Klassen `Or` und `And`.
- Testen Sie Ihre Implementierung mit folgenden Boolschen Ausdrücken
  - `Tree = a AND( b OR c )`
  - `Tree = (a AND b) OR c`
  - `Tree = (a OR b) AND c`
  - `Tree = (a AND b) AND c` ... entspricht das `a AND b AND c` ?

## Hilfestellungen

Zunächst ein paar Definitionen:
- `Atomare Formeln` sind die Booleschen Konstanten 0 (false) und 1 (true) wie auch Variablen a, b, c, etc.
- `Boolsche Ausdrücke` setzen sich aus `atomaren Formeln` und `Verknüpfungsoperatoren` (`&&`, `||`, `!`, `^`) zusammen.
- `Boolsche Ausdrücke` können wieder aus `boolschen Ausdrücken` und `atomaren Formel` zusammengesetzt werden.

`Boolsche Ausdrücke` können durch Syntaxbäume veranschaulicht werden:
- Dabei wird die atomare Formel durch einen Knoten mit Variablennamen dargestellt.
- Der boolsche Ausdruck setzt sich aus einem Knoten mit Verknüpfungsoperator und 1 oder 2 Unterknoten zusammen.
- Diese können selbst wieder boolsche Ausdrücke sein oder auch atomare Formeln.
- Letztere nennt man dann auch Blätter des Baums.

Hier ein Beispiel eines Syntaxbaumes: 

<img alt="Baum" src="Hilfestellungen/baum.png" width="250"/>  

Dies entspricht dem Boolschen Term: `Baum = a OR ( b AND c )`

## Videos
- Syntaxbäume generell: https://www.youtube.com/watch?v=oJjRXgCb5S4
- Boolsche Ausdrücke: https://www.youtube.com/watch?v=MhS_NHY-aRI


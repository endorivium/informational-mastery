# Übung 11

In dieser Übung beschäftigen Sie sich mit Methodenüberschreibung, Vergleich und Iteration.

## Kernthemen
- Fokus: Redefinition einer Auswahl an Methoden der `Object`- Klasse: 
  - `toString()`, `equals()`, `hashCode()`
- Fokus: Vergleichen
  - Erstellung einer eigenen Ordnung für Objekte anhand der Interfaces `Comparable<T>` und `Comparator<T>`
- Fokus: Iteration
  - Eigene Implementierung von `Iterator<CompactDisc>`
  - Anwendung in for-each- und while-Schleifen

## Aufgabe 1 :  Klasse CD
Gegeben ist die Klasse `CompactDisc` mit den Attributen `Interpret`, `Titel`, `Erscheinungsjahr` und `Plattenlabel`. 
Sie verfügt über Konstruktoren und Getter-Methoden. Die Klasse soll immutable sein.
- Überschreiben Sie an den gekennzeichneten Stellen die Methoden `toString()`, `equals()` und `hashCode()` der `Object`-Klasse. 
  - Zwei CDs sollen gleich sein, wenn Interpret und Titel übereinstimmen (ohne Berücksichtigung der Groß-und Kleinschreibung).
- Überprüfen Sie nach Ihrer Implementierung, ob die Klasse wirklich immutable ist.

Testen Sie Ihre Implementierung mit dem vorgegebenen JUnit Testtreiber [TestCompactDisc](src/test/java/oop/th/rosenheim/TestCompactDisc.java).

**Hinweise:** Nutzen Sie zum Überschreiben gern die Schemata aus den Vorlesungsfolien.

## Aufgabe 2: Interface Comparable
Das Interface `Comparable` wird für die „natürliche“ Ordnung von Objekten definiert. Es ist in der Java-Bibliothek vorgegeben:
```java
package java.lang;
import java.util.*;

public interface Comparable<T> {
    public int compareTo(T o);
}
```
Implementieren Sie das Interface `Comparable` für die Klasse `CompactDisc`. Ordnen Sie dabei CDs
wie im Plattenladen, das heißt nach Interpret, wobei jedoch führende „der“, „die“, „das“, „ein“, „eine“,
„einer“, „eines“, „the“, „a“ und „an“ nicht berücksichtigt werden. Zum Beispiel:
- „Die Toten Hosen“ steht unter „T“
- „The Who“ unter „W“

Testen Sie Ihre Implementierung mit dem vorgegebenen JUnit Testtreiber [TestCompactDisc](src/test/java/oop/th/rosenheim/TestCompactDisc.java).

**Hinweise:**

- `<T>` beschreibt dabei einen generischen Typ. An dessen Stelle werden konkrete Typen treten, in unserem Fall `CompactDisk`. 
- Gehen Sie davon aus, dass das Attribut für den Interpreten niemals `null` ist
- Verwenden Sie ggfs. geeignete Hilfsmethoden der Klasse String, wie z.B. die Methode
  `trim()`, um führende oder abschließende Leerzeichen zu entfernen.
  https://docs.oracle.com/javase/8/docs/api/java/lang/String.html
- Die Klasse `Arrays` verfügt über eine Reihe von (statischen) Methoden, die je nach gewähltem
  Lösungsansatz hilfreich sein können, z.B. `sort()`, `copyOf()`, `binarySearch()`
  https://docs.oracle.com/javase/8/docs/api/java/util/Arrays.html

## Aufgabe 3: Interface Comparator – Vergleich nach Erscheinungsjahr

Falls benötigt, können auch alternative Ordnungen über das Interface `Comparator<T>` definiert werden. 

- Schreiben Sie eine Klasse `YearOfPublicationComparator`, die einen Comparator für
  `CompactDiscs` implementiert, der diese nach dem Erscheinungsjahr ordnet.
 
Testen Sie mit der Methode `testYearOfPublicationComparator()` der JUnit Testklasse
[TestCompactDisc](src/test/java/oop/th/rosenheim/TestCompactDisc.java). 

- [Optional]: Was müssten Sie tun, um eine weitere Ordnung zu implementieren? Vielleicht hilft Ihnen die Testerklasse [TestInterpreterTitleComparator](src/test/java/oop/th/rosenheim/TestInterpreterTitleComparator.java) dabei.

## Aufgabe 4: Vorwärts- und Rückwärtsiteration mit `CompactDiscCollection`

Stellen Sie sich vor, Ihre CompactDiscs werden nun mittels einer Datenstruktur verwaltet. Hierzu erhalten Sie zwei vollständig vorbereitete Klassen:

- `CompactDiscNode`: ein Element einer doppelt verketteten Liste, das ein `CompactDisc`-Objekt sowie Referenzen auf vorherige und nachfolgende Elemente speichert.
- `CompactDiscCollection`: verwaltet eine Sammlung von `CompactDisc`-Objekten in einer doppelt verketteten Liste.

In der Klasse `CompactDiscCollection` sind die Methoden `iterator()` und `reverseIterator()` **vorbereitet** und sollen in dieser Aufgabe vervollständigt werden. Es sollen auch die konkreten Iterator-Klassen (`ForwardIterator` und `ReverseIterator`) eingefügt werden.

### 1. `ForwardIterator` implementieren

- Erstellen Sie eine **innere Klasse `ForwardIterator`** in `CompactDiscCollection`.
- Implementieren Sie das Interface `Iterator<CompactDisc>`.
- Attribut: `CompactDiscNode current`, initialisiert mit `head`.
- `hasNext()` prüft `current != null`
- `next()` gibt `current.data` zurück und verschiebt `current = current.next`

### 2. `ReverseIterator` implementieren

- Analog zu `ForwardIterator`, aber Startpunkt ist `tail`
- `current = current.prev` nach jedem Schritt

### 3. Methoden ergänzen

- `iterator()` gibt `new ForwardIterator(head)` zurück
- `reverseIterator()` gibt `new ReverseIterator(tail)` zurück

**Hinweis:**  Sobald Ihre Klasse `CompactDiscCollection` das Interface `Iterable<CompactDisc>` implementiert und `iterator()` korrekt implementiert ist, können Sie automatisch eine for-each-Schleife auf der Sammlung verwenden. Hierzu gibt es einen extra JUnit Test, der das verdeutlicht (siehe nächste Aufgabe).

### 4. Testen Sie Ihre Implementierung mittels Unit Tests
Testen Sie Ihre Implementierungen mit der Testklasse [CompactDiscCollectionTest](src/test/java/oop/th/rosenheim/CompactDiscCollectionTest.java).
Wir haben einen TestDriver vorgegeben. Versuchen Sie diesen mit Ihrer Implementierung auszuführen.


package sample_solution;
import java.util.Comparator;


public class YearOfPublicationComparator implements Comparator<CompactDisc> {
 	@Override
	public int compare(CompactDisc arg0, CompactDisc arg1) {
		// use Integer.compare()
		return Integer.compare(arg0.getYearOfPublication(), arg1.getYearOfPublication());
		// Alternative solution:
		/*
		if (arg0.getYearOfPublication() < arg1.getYearOfPublication())
			return -1;
		else if (arg0.getYearOfPublication() > arg1.getYearOfPublication())
			return 1;
		else
			return 0;
		*/

	}
}


/*
Alternative without generics
public class YearOfPublicationComparator implements Comparator {
    @Override
    public int compare(Object o0, Object o1) {
        CompactDisc arg0 = (CompactDisc) o0;
        CompactDisc arg1 = (CompactDisc) o1;

        if (arg0.getYearOfPublication() < arg1.getYearOfPublication())
            return -1;
        else if (arg0.getYearOfPublication() > arg1.getYearOfPublication())
            return 1;
        else
            return 0;
    }
}
*/
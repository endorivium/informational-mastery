package oop.th.rosenheim;

public class CompactDisc {

    private final String interpreter;
    private final String title;
    private final int yearOfPublication;
    private final String recordLabel;

    /**
     * Konstruktor
     * @param interpreter: Interpret der CD
     * @param title: Titel der CD
     * @param yearOfPublication: Jahr der Veröffentlichung
     * @param recordLabel: Plattenlabel
     */
    public CompactDisc(String interpreter, String title, int yearOfPublication, String recordLabel) {
        this.interpreter = interpreter;
        this.title = title;
        this.yearOfPublication = yearOfPublication;
        this.recordLabel = recordLabel;
    }

    // Getter (no setter since immutable class is required)
    /**
     * Getter for Interpreter
     * @return String interpreter
     */
    public String getInterpreter() {
        return interpreter;
    }
    /**
     * Getter for Title
     * @return String title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Getter for YearOfPublication
     * @return String yearOfPublication
     */
    public int getYearOfPublication() {
        return yearOfPublication;
    }
    /**
     * Getter for RecordLabel
     * @return String RecordLabel
     */
    public String getRecordLabel() {
        return recordLabel;
    }

    /**
     * Override the toString Method
     * @return String text
     */
    @Override
    public String toString() {
        // todo implement toString
        return null;
    }

    /*
     * Override the equals Method
     * @param obj
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) {
        // todo implement equals
        return false;
    }

    /*
      Override the hashCode Method
      @return int hashCode
     */
    @Override
    public int hashCode() {
        // todo implement hashCode
        return 0;
    }


}

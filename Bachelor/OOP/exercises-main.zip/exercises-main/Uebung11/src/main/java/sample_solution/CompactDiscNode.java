package sample_solution;

/**
 * Diese Klasse repräsentiert einen Knoten in einer doppelt verketteten Liste.
 * Jeder Knoten enthält ein CompactDisc-Objekt sowie Verweise auf den
 * vorherigen und den nächsten Knoten in der Liste.
 */
public class CompactDiscNode {

    // Das gespeicherte CompactDisc-Objekt in diesem Knoten
    public CompactDisc data;

    // Verweis auf den nächsten Knoten in der Liste
    public CompactDiscNode next;

    // Verweis auf den vorherigen Knoten in der Liste
    public CompactDiscNode prev;

    /**
     * Konstruktor – erstellt einen neuen Knoten mit gegebener CompactDisc.
     * Die Nachfolger- und Vorgängerreferenzen werden zunächst auf null gesetzt.
     *
     * @param data Das CompactDisc-Objekt, das im Knoten gespeichert werden soll
     */
    public CompactDiscNode(CompactDisc data) {
        this.data = data;
        this.next = null;  // wird später beim Einfügen in die Liste gesetzt
        this.prev = null;  // wird später beim Einfügen in die Liste gesetzt
    }
}

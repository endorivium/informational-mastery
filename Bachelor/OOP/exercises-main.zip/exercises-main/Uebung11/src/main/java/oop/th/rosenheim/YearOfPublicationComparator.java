package oop.th.rosenheim;

public class YearOfPublicationComparator {

	// Todo: Implement InterpreterTitleComparator

}
package sample_solution;
import java.util.Arrays;


public class CompactDisc implements Comparable<CompactDisc> {

	private final static String[] TO_REMOVE = {"der", "die", "das", "ein", "eine", "einer", "eines", "the", "a"}; // immutable

	// attributes
	private final String interpreter;
	private final String title;
	private final int yearOfPublication;
	private final String recordLabel;

	// Getter (no setter since immutable class is required)
	/**
	 * Getter for Interpreter
	 * @return String interpreter
	 */
	public String getInterpreter() {
		return interpreter;
	}
	/**
	 * Getter for Title
	 * @return String title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Getter for YearOfPublication
	 * @return String yearOfPublication
	 */
	public int getYearOfPublication() {
		return yearOfPublication;
	}
	/**
	 * Getter for RecordLabel
	 * @return String RecordLabel
	 */
	public String getRecordLabel() {
		return recordLabel;
	}

	/**
	 * Konstruktor
	 * @param interpreter
	 * @param title
	 * @param yearOfPublication
	 * @param recordLabel
	 */
	public CompactDisc(String interpreter, String title, int yearOfPublication, String recordLabel) {
		this.interpreter = interpreter;
		this.title = title;
		this.yearOfPublication = yearOfPublication;
		this.recordLabel = recordLabel;
	}


	@Override
	/**
	 * Override the toString Method
	 * @return String text
	 */
	public String toString() {
		return "CD: '" + title + "' von '" + interpreter + "' im Jahr "
				+ yearOfPublication + " bei '" + recordLabel + "'";
	}

	@Override
	/**
	 * Override the hashCode Method
	 * @return int hashCode
	 */
	public int hashCode() {

		int result = (interpreter == null) ? 0 : interpreter.toLowerCase().hashCode();
		result = 31 * result + ((title == null) ? 0 : title.toLowerCase().hashCode());
		return result;
	}

	@Override
	/**
	 * Override the equals Method
	 * @return boolean
	 */
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (obj == this)
			return true;
		if (this.getClass() != obj.getClass())
			return false;

		CompactDisc other = (CompactDisc) obj;


		if (interpreter == null) {
			if (other.interpreter != null)
				return false;
		} else if (!interpreter.toLowerCase().equals(other.interpreter.toLowerCase()))
			return false;

		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.toLowerCase().equals(other.title.toLowerCase()))
			return false;
		return true;
 	}


	@Override
	/**
	 * Override compareTo Method from Interface java.util.Comparable
	 * @return int
	 */
	public int compareTo(CompactDisc other) {

		// sort tokens that should not be considered ("der", "die", "das", ...)
		String[] toRemoveSorted = Arrays.copyOf(TO_REMOVE, TO_REMOVE.length);
		Arrays.sort(toRemoveSorted);

		// determine first word for both interpreters (in lower case)
		String interpreterLC = interpreter.toLowerCase();
		String otherInterpreterLC = other.interpreter.toLowerCase();
		String thisFirstToken = interpreterLC.split(" ")[0];
		String otherFirstToken = otherInterpreterLC.split(" ")[0];

		// check for both interpreters if first word must be ignored -> if yes then remove it
		if(Arrays.binarySearch(toRemoveSorted, thisFirstToken) >= 0) {
			interpreterLC = interpreterLC.substring(thisFirstToken.length());
		}
		if(Arrays.binarySearch(toRemoveSorted, otherFirstToken)>=0) {
			otherInterpreterLC = otherInterpreterLC.substring(otherFirstToken.length());
		}

		// call compareTo on the two strings (class String already implements compareTo method)
		return interpreterLC.trim().compareTo(otherInterpreterLC.trim());
	}

    /*
	// Alternatively : implementation with regular expression
	@Override
	public int compareTo(CompactDisc other) {

	    String toReplace = "(?i)\\b((der)|(die)|(das)|(ein)|(eine)|
	    (einer)|(eines)|(the)|(a))\\s+";
	    // (?i) - case insensitive
	    // ((der)|(die)|(das)|(ein)|(eine)|(einer)|(eines)|(the)|(a)) sucht nach genau einem dieser Wörter
	    // \\s - whitespace zeichen -- es findet also "der " "die ", ...
	    // Obacht: DieTotenHosen wird nicht gefunden!
	    // Obacht: wieder Hund wird auch gefunden!
	    // -->
	    // \\b - für Wortgrenze
	    // \\s+ - erlaubt ein oder mehrere Whitespaces


	    return this.interpreter.replaceFirst(toReplace, "").trim().
	    compareToIgnoreCase(
	    other.interpreter.replaceFirst(toReplace, "").trim());
	}
	*/


}



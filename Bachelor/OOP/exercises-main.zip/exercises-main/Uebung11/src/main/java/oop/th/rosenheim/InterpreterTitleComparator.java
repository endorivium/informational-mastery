package oop.th.rosenheim;

import java.util.Comparator;

public class InterpreterTitleComparator {
	// Todo: Implement InterpreterTitleComparator
	// Obacht: Die Tests laufen so noch nicht durch!
}
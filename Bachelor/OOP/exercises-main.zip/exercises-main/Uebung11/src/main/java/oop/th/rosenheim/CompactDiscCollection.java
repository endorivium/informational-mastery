package oop.th.rosenheim;

import java.util.Comparator;
import java.util.Iterator;

/**
 * Diese Klasse verwaltet eine Sammlung von CompactDiscs in Form einer
 * doppelt verketteten Liste. Neue Elemente werden entsprechend eines
 * übergebenen Comparators sortiert eingefügt.
 */
public class CompactDiscCollection implements Iterable<CompactDisc> {

    // Referenz auf den ersten Knoten der Liste
    private CompactDiscNode head;

    // Referenz auf den letzten Knoten der Liste
    private CompactDiscNode tail;

    // Comparator zur Festlegung der Sortierreihenfolge
    private Comparator<CompactDisc> comparator;

    /**
     * Konstruktor – erzeugt eine neue leere CD-Sammlung mit gegebener Vergleichslogik.
     *
     * @param comparator Ein Comparator, der die Sortierreihenfolge definiert
     */
    public CompactDiscCollection(Comparator<CompactDisc> comparator) {
        this.comparator = comparator;
        this.head = null;
        this.tail = null;
    }

    /**
     * Fügt eine neue CD sortiert in die Sammlung ein.
     * Die Reihenfolge ergibt sich aus dem übergebenen Comparator.
     *
     * @param cd Die einzufügende CompactDisc
     */
    public void add(CompactDisc cd) {
        CompactDiscNode newNode = new CompactDiscNode(cd);

        // Fall: Liste ist leer
        if (head == null) {
            head = tail = newNode;
            return;
        }

        // Suche die Position, an der die neue CD eingefügt werden soll
        CompactDiscNode current = head;
        while (current != null && comparator.compare(cd, current.data) > 0) {
            current = current.next;
        }

        if (current == head) {
            // Einfügen am Anfang der Liste
            newNode.next = head;
            head.prev = newNode;
            head = newNode;

        } else if (current == null) {
            // Einfügen am Ende der Liste
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;

        } else {
            // Einfügen zwischen zwei bestehenden Knoten
            CompactDiscNode prevNode = current.prev;
            prevNode.next = newNode;
            newNode.prev = prevNode;
            newNode.next = current;
            current.prev = newNode;
        }
    }

    /**
     * Gibt einen Iterator zurück, der die CDs vorwärts (beginnend beim Kopf) durchläuft.
     *
     * @return Ein Iterator über die CompactDiscs
     */
    @Override
    public Iterator<CompactDisc> iterator() {
        // TODO: ForwardIterator implementieren
        return null;
    }

    /**
     * Gibt einen Iterator zurück, der die CDs rückwärts (beginnend beim Ende) durchläuft.
     *
     * @return Ein Iterator in umgekehrter Reihenfolge
     */
    public Iterator<CompactDisc> reverseIterator() {
        // TODO: ReverseIterator implementieren
        return null;
    }

    /*
    // Innere Klasse für den Vorwärts-Iterator
    private class ForwardIterator implements Iterator<CompactDisc> {
        // TODO: Implementieren
    }

    // Innere Klasse für den Rückwärts-Iterator
    private class ReverseIterator implements Iterator<CompactDisc> {
        // TODO: Implementieren
    }
    */
}

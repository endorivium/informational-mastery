package sample_solution;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;

public class CompactDiscCollectionTest {

    private CompactDiscCollection collection;

    // auskommentieren sobal InterpreterTitleComparator vorhanden ist
    @BeforeEach
    public void setUp() {
        collection = new CompactDiscCollection(new InterpreterTitleComparator());
        collection.add(new CompactDisc("The Beatles", "Abbey Road", 1969, "Apple Records"));
        collection.add(new CompactDisc("Queen", "A Night at the Opera", 1975, "EMI"));
        collection.add(new CompactDisc("Pink Floyd", "The Wall", 1979, "Harvest Records"));
    }

    @Test
    public void testForwardIterator() {
        Iterator<CompactDisc> it = collection.iterator();
        assertTrue(it.hasNext());
        assertEquals("CD: 'Abbey Road' von 'The Beatles' im Jahr 1969 bei 'Apple Records'", it.next().toString());
        assertEquals("CD: 'The Wall' von 'Pink Floyd' im Jahr 1979 bei 'Harvest Records'", it.next().toString());
        assertEquals("CD: 'A Night at the Opera' von 'Queen' im Jahr 1975 bei 'EMI'", it.next().toString());
        assertFalse(it.hasNext());
    }

    @Test
    public void testReverseIterator() {
        Iterator<CompactDisc> it = collection.reverseIterator();
        assertTrue(it.hasNext());
        assertEquals("CD: 'A Night at the Opera' von 'Queen' im Jahr 1975 bei 'EMI'", it.next().toString());
        assertEquals("CD: 'The Wall' von 'Pink Floyd' im Jahr 1979 bei 'Harvest Records'", it.next().toString());
        assertEquals("CD: 'Abbey Road' von 'The Beatles' im Jahr 1969 bei 'Apple Records'", it.next().toString());
        assertFalse(it.hasNext());
    }


    @Test
    public void testForEachLoopUsesForwardIterator() {
        StringBuilder sb = new StringBuilder();
        for (CompactDisc cd : collection) {
            sb.append(cd.toString()).append("\\n");
        }

        String expected = ""
                + "CD: 'Abbey Road' von 'The Beatles' im Jahr 1969 bei 'Apple Records'\\n"
                + "CD: 'The Wall' von 'Pink Floyd' im Jahr 1979 bei 'Harvest Records'\\n"
                + "CD: 'A Night at the Opera' von 'Queen' im Jahr 1975 bei 'EMI'\\n";

        assertEquals(expected, sb.toString());
    }

}

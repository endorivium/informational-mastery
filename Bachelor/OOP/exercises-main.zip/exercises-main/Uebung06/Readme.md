## Übung 06: Warteschlangen, Junit

In dieser Übung implementieren Sie das Konzept einer Warteschlange (engl. Queue). Queues arbeiten nach dem `First In – First Out (FIFO)` Prinzip. In der Praxis
kommen Warteschlangen z.B. bei Druckaufträgen zum Einsatz. Der älteste Druckauftrag wird immer zuerst bearbeitet, erst dann der Zweitälteste, etc. Es können zu jeder Zeit neue Druckaufträge hinzukommen.

## Kernthemen
- Verknüpfen von Objekten
- Implementierung von Code anhand eines UML-Diagramms
- Schreiben von eigenen Testmethoden mithilfe von JUnit5
- Dokumentation des Codes mit JavaDoc

## Aufgbabe 1: Implementierung der Datenstruktur
Auf diesem Übungsblatt soll die Grundlage für ein Ticketsystem implementiert werden. Personen, die zuerst ein Ticket ziehen, werden auch zuerst bedient. Dabei wird eine Person durch die vorgegebene und bereits bekannte Klasse `Contact` repräsentiert. Sie sollen eine Klasse `Queue` implementieren, die die folgenden Eigenschaften besitzt: 

- `public Queue()`: Default-Konstruktor, legt eine neue, leere Warteschlange an.
- `public void enqueue(Contact c)`: Fügt der Warteschlange einen neuen Kontakt hinzu.
- `public Contact dequeue()`: Entfernt den ältesten Kontakt aus der Warteschlange.
- Neben diesen drei Methoden sollen Getter-Methoden implementiert werden (siehe UML).

Die Warteschlange wird über eine einfach verkettete Liste wie auf dem letzten Übungsblatt umgesetzt. Allerdings kann man von einem Objekt der Klasse Queue nun zu zwei Objekten der Klasse `Contact` „navigieren“:

- `head`: Zeigt auf den ältesten Kontakt, der als nächstes entfernt wird
- `tail`: Zeigt auf den jüngsten/neuesten Kontakt, das der Warteschlange hinzugefügt wurde.

<br>

  ![Die Liste](Hilfestellungen/visualisierungDerListe.png)
  
Von jedem Kontakt gelangt man wie auf dem letzten Übungsblatt durch das Attribut `next` zum nächsten Kontakt.

### UML-Klassendiagramm:

![UML_Diagramm](Hilfestellungen/UMLDiagramm.png)

**Implementieren Sie die Klasse `Queue` entsprechend der Vorgaben.**

Die Klasse `Contact` ist bereits vorgegeben (aus Übung 5).

**Tipp:** 
Setzen Sie in der Methode `enqueue(.)` vorsichtshalber das Attribut `next` des einzufügenden Kontaktes `c` auf `null`.

## Aufgabe 2: Javadoc

Versehen Sie die Klasse `Queue` mit Javadoc-Kommentaren und erzeugen Sie die Javadoc-Dokumentation.

## Aufgabe 3: JUnit5

Testen Sie Ihre Implementierung der Klasse `Queue`, in dem Sie JUnit-Tests in der Testklasse [QueueTest](src/test/java/oop/th/rosenheim/QueueTest.java) schreiben. Implementieren Sie die in der folgenden Tabelle aufgelisteten Testaufgaben.

![Beschreibung der Junit Methoden](Hilfestellungen/junit.png)

#### Hinweise:
- IntelliJ kann die Testklasse automatisch generieren.
- Für jede Testmethode sollen neue, eigene Objekte (auch Kontakte) angelegt werden.
- Verwenden Sie `assertTrue`, `assertEquals`, `assertSame`, etc. Anweisungen!

## Hilfestellung
- Video zur Queue: https://www.youtube.com/watch?v=iMs2Fq8O9T4
- Webbasierte Queue: https://www.cs.usfca.edu/~galles/visualization/QueueLL.html
- Wir haben ein Testgerüst vorbereitet: [QueueTest](src/test/java/oop/th/rosenheim/QueueTest.java)
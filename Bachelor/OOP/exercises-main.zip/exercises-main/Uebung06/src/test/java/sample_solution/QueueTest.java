package sample_solution;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static java.time.Duration.ofMillis;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Junit5 Tester to test Queue.java
 *
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified 	    4.5.2017, Wolfgang Mühlbauer
 * Adapted to Junit5  4.4.2020, Silke Lechner-Greite
 */

class QueueTest {

    private Queue queue;
    private Contact contact1;
    private Contact contact2;
    private Contact contact3;


    @BeforeEach
    void setUp() {
        queue = new Queue();
        contact1 = new Contact("Berger", 31232);
        contact2 = new Contact("Huber", 83882);
        contact3 = new Contact("Maier", 29399);
    }

    @Test
    void testCreateQueue() {
        assertNull(queue.getTail(),"Tail");
        assertNull(queue.getHead(),"Head");
        assertEquals(0, queue.getNumContacts(),"Num contacts");
        // Hint: more assertions: https://junit.org/junit5/docs/5.0.1/api/org/junit/jupiter/api/Assertions.html
    }


    @Test
    void testEnqueue() {
        queue.enqueue(contact1);
        queue.enqueue(contact2);
        queue.enqueue(contact3);
        assertEquals(3, queue.getNumContacts(),"Number contacts");
        assertSame(contact3, queue.getTail(),"Tail");
        assertSame(contact1, queue.getHead(),"Head");
    }

    @Test
    void testDequeue() {
        queue.enqueue(contact1);
        queue.enqueue(contact2);
        queue.enqueue(contact3);
        Contact c = queue.dequeue();
        assertSame(contact1, c,"Removed elem");
        assertSame(contact3, queue.getTail(),"Tail");
        assertSame(contact2, queue.getHead(),"Head");
    }

    @Test
    void testDequeueLastElement() {
        queue.enqueue(contact1);
        Contact c = queue.dequeue();
        assertEquals(0, queue.getNumContacts(),"Number of queue elements");
        assertNull(queue.getTail(),"Tail");
        assertNull(queue.getHead(),"Head");
    }


    @Test
    void testPerformance() {
        assertTimeout(ofMillis(50), () -> { // 50 ms
            for (int i = 0; i < 1000; i++) {
                Contact c = new Contact("Name" + i, i);
                queue.enqueue(c);
            }
        });
    }

    @Test
    void testContactCounter() {
        int before = Contact.getContactCounter();
        Contact c = new Contact("Mustermann", 32168);
        int after = Contact.getContactCounter();
        assertEquals(1, after-before);
    }
}

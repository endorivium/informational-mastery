﻿package oop.th.rosenheim;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Junit5 Tester to test Queue.java
 *
 * @author  	Professoren der Informatikfakultät
 * @version     1.0
 * Modified 	    4.5.2017, Wolfgang Mühlbauer
 * Adapted to Junit5  4.4.2020, Silke Lechner-Greite
 */
class QueueTest {

    @BeforeEach
    void setUp() {
        //todo Erstellen Sie drei Kontakte und eine leere Queue.
    }

    @Test
    void testCreateQueue() {
        //todo überprüfen Sie, ob Anfang und Ende einer neuen Queue leer sind und die Anzahl der Kontakte auch 0 ist.
		//More assertions: https://junit.org/junit5/docs/5.0.1/api/org/junit/jupiter/api/Assertions.html
    }


    @Test
    void testEnqueue() {
        // todo fügen Sie die kontakte in die Queue ein und überprüfen Sie das.
    }

    @Test
    void testDequeue() {
        // todo entfernen Sie die Kontakte und ü+berprüfen Sie das.
    }

    @Test
    void testDequeueLastElement() {
       //todo fügen Sie einen Kontakt ein und entferen Sie diesen wieder
    }


    @Test
    void testPerformance() {
		
        //todo fügen Sie tausend Kontakte ein und überprüfen Sie die Performanz
		//todo beutzen Sie assertTimeout mit 50ms timeout Zeit						   
    }

    @Test
    void testContactCounter() {
       //todo überprüfen Sie, ob der Kontaktzähler richtig funktioniert
    }

}
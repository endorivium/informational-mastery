package oop.th.rosenheim;

public class Queue {

    // number of contacts saved in queue
    private int numContacts;

    // last contact added
    private Contact tail;

    // next contact to be removed
    private Contact head;

    //generates an empty queue
    public Queue() {
        tail = null;
        head = null;
        numContacts = 0;
    }

    //inserts a new contact into the queue
    public void enqueue(Contact c) {
      // make sure that element to be added does not point to any other element
      
    }

    //removes contact from the queue
    public Contact dequeue() {
        // only remove element if there is at least one element in the queue
        return null;
	}

    //get tail of queue
    public Contact getTail() {
        return null;
    }

    //get head of queue
    public Contact getHead() {
        return null;
    }

    //get number of contacts stored in queue
    public int getNumContacts() {
        return 0;
    }
}

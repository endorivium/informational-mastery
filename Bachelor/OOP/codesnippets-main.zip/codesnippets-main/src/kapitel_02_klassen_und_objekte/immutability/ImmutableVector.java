package kapitel_02_klassen_und_objekte.immutability;

public final class ImmutableVector {
    private final int x;
    private final int y;
    private final VectorLength length;

    public ImmutableVector (int x, int y) {
        this.x = x;
        this.y = y;
        this.length = new VectorLength((float)Math.sqrt(x * x + y * y));
    }
    public VectorLength getLength() { return this.length; }
}


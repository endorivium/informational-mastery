package kapitel_02_klassen_und_objekte.immutability;

public final class VectorLength {

    private final float length;

    public VectorLength(float length) { this.length = length; }

    public float getLength() { return this.length; }

    // public void setLength(float length) { this.length = length; }
}

package kapitel_02_klassen_und_objekte.immutability;

public class TestImmutability {
    /*public static void main(String[] args) {
        ImmutableVector vec = new ImmutableVector(3, 4); // Länge: 5.0
        System.out.println("Ursprüngliche Länge: " + vec.getLength().getLength());

        // Missbrauch der öffentlichen Referenz auf das mutable Objekt:
        vec.getLength().setLength(99.0f);

        // Nach außen verändert, obwohl die Klasse „immutable“ scheint:
        System.out.println("Manipulierte Länge: " + vec.getLength().getLength());
    }*/
}
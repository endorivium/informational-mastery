package kapitel_02_klassen_und_objekte.static_vs_dynamic;


/**
 * Spielbrett, welches von allen Spielern verwendet wird.
 */
public class Spielbrett {
    static String[] felder = new String[10]; // 10 Spielfelder

    public static void init() {
        for (int i = 0; i < felder.length; i++) {
            felder[i] = null;
        }
    }

    public static boolean setFeld(int pos, String symbol) {
        if (pos >= 0 && pos < felder.length && felder[pos] == null) {
            felder[pos] = symbol;
            return true;
        } else {
            return false;
        }
    }

    public static void anzeigen() {
        for (String feld : felder) {
            System.out.print("[" + feld + "]");
        }
        System.out.println();
    }
}

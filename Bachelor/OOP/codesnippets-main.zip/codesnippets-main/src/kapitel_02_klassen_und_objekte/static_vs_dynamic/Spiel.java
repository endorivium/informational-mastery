package kapitel_02_klassen_und_objekte.static_vs_dynamic;

import java.util.Random;

public class Spiel {
    public static void main(String[] args) {



        Spielbrett.init();
        Spielbrett.anzeigen();

        Spieler alice = new Spieler("Annina", "A");
        Spieler bob = new Spieler("Bert", "B");

        Random ran = new Random();

        for (int runde = 1; runde <= 5; runde++) {
            System.out.println("Runde " + runde);
            alice.zug(ran.nextInt(10));
            bob.zug(ran.nextInt(10));
            Spielbrett.anzeigen();
            alice.status();
            bob.status();
            System.out.println("--------------------------");
        }
    }
}
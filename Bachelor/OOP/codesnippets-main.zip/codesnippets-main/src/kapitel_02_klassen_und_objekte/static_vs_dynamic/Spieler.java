package kapitel_02_klassen_und_objekte.static_vs_dynamic;

public class Spieler {

    private String name;
    private String symbol;
    private int punkte;

    public Spieler(String name, String symbol) {
        this.name = name;
        this.symbol = symbol;
        this.punkte = 0;
    }

    public void zug(int pos) {
        System.out.println(name + " versucht Feld " + pos);
        if (Spielbrett.setFeld(pos, symbol)) {
            punkte += 10;
        } else {
            System.out.println("❌ Feld " + pos + " ist bereits belegt!");
            punkte -= 2;
        }
    }

    public void status() {
        System.out.println(name + " hat " + punkte + " Punkte.");
    }
}
package kapitel_02_klassen_und_objekte.stopwatch;

public class StopWatch2 {

    // instance variables
    private long start;
    private long stop;
    private Time elapsedTime;
    private boolean isTracking;

    // constructor
    public StopWatch2() {
        start = 0L;
        stop = 0L;
        elapsedTime = new Time();
        isTracking = false;
    }

    // methods
    public void start() {
        if(!isTracking) {
            start = System.currentTimeMillis();
            isTracking = true;
        }
    }

    public void stop() {
        if (isTracking) {
            stop = System.currentTimeMillis();
            isTracking = false;
        }
    }

    public String elapsedTime() {
        long time;
        if (isTracking) {
            time = System.currentTimeMillis() - start;
        } else {
            time = stop - start;
        }
        elapsedTime.setTime(time);
        return elapsedTime.toString();
    }

    // getter & setter - if needed
    public boolean isTracking() {return isTracking;}

}

package kapitel_02_klassen_und_objekte.stopwatch;

import java.util.Scanner;

public class TrackTime {

    public static void keyTyped(int key, StopWatch2 stopwatch) {
        switch (key) {
            case 1:
                stopwatch.start();
                System.out.println("Tracking started ...");
                break;
            case 2:
                stopwatch.stop();
                System.out.println("... Tracking stopped.");
                System.out.println("Tracked time: " + stopwatch.elapsedTime() + "s.");
                break;
            default:
                System.out.println("Wrong input.");
                break;
        }
    }

    public static void main(String[] args) {

        StopWatch2 stopwatch = new StopWatch2();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Stop watch ready ... press [1] to start and [2] to stop ...");
        keyTyped(Integer.parseInt(scanner.next()), stopwatch);
        while(stopwatch.isTracking()){
            keyTyped(Integer.parseInt(scanner.next()), stopwatch);
        }
    }
}

package kapitel_02_klassen_und_objekte.stopwatch;

public class Time {

    private long seconds;
    private long hundredth;

    public Time (long seconds, long hundredth) {
        this.seconds = seconds;
        this.hundredth = hundredth;
    }
    public Time() {
        this(0,0);
        System.out.println();
    }

    @Override
    public String toString() {
        return "" + seconds + "." + hundredth + "s";
    }

    //this method sets the times without hundredth/seconds calculation
    public void setTime(long seconds, long hundredth) {
        this.seconds = seconds;
        this.hundredth = hundredth;
    }

    //this method takes care of the hundredth/seconds calculation
    public void setTime(long time) {
        this.seconds = time/1000;
        this.hundredth = time%1000;
    }

}

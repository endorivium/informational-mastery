package kapitel_01_java_basics;

import java.util.Random;
import java.util.Scanner;

public class SummaryChapter1 {

    // Dies ist eine Illustration an Java-Inhalten,
    // die im ersten Vorlesungskapitel behandelt wurden.

    // 1. Java Entwicklungsumgebung installieren und erste Programme kompilieren --- ok
    // 2. IntelliJ installieren und Übung 1 - 2 darin programmieren --- ok

    // 3. Erstes Java Programm "Quadrat"
    // Wichtige Inhalte dabei waren:
    // - Klassendeklaration <sichtbarkeit> [static] class Klassenname { < Rumpf > } // Klassennamen beginnen mit Großbuchstaben
    // - Klassenname, sollte dem Namen der Datei entsprechen (mit .java)
    // - Prozedural gesehen: nur eine Klasse mit Hilfsfunktionen
    // - public static void main (String[] args) { <Rumpf> } == Einstiegsmethode ins ausführende Programm
    // Kommentar einzeilig
    /*  Kommentar
        mehrzeilig
     */

    // Das heißt in Bezug auf diesen Spicker:
    // - Klassendefinition SpickerKapitel1
    // - Main Methode
    // - Hilfsmethode

    // 4. Die Main Methode
    public static void main(String[] args) {

        System.out.println("Java Prozedural ...");

        // 5. Anweisungen in Java:
        int a = 5; // Datentyp Name = Wertzuweisung;
        int b = 6;
        System.out.println("Ergebnis Anweisung: " + (a + b));

        // 6. Blöcke: wird mit geschweiften Klammern festgelegt: { }
        // Bündelt eine Sammlung von Anweisungen
        {
            int d = 0;   // Wichtig: Wertebreiche der Variablen: d wurde
            // innerhalb eines Blocks definiert, ist dann auch nur darin existent
        }
        //System.out.println(d);

        // 7. Aufruf einer Hilfsmethode (1 Hilfsmethode beschreiben, dann wie sie aufgerufen wird
        // Das Ergebnis der Hilfsmethode kann direkt verwendet oder n Variablen zwischengespeichert werden
        System.out.println(doppelterWert(7));

        // 8. Kontrollstrukturen:
        // if-else
        if (a > 0)
            b = a;  // b wird mit positivem a überschrieben
            // Obacht: keine geschweiften Klammern. Dies ist nur möglich, da die Anweisung aus einer Zeile besteht.
            // sollte da zB noch ein a++ kommen, dann braucht es geschweifte Klammern
        else
            b = -a; // b wird mit negativem a überschrieben

        // if-else
        Random random = new Random();
        int x = random.nextInt(10);
        if (x == 0) {
            System.out.println("Die Zufallszahl ist 0.");
        } else if (x > 0 && x < 10) {
            System.out.println("Die Zufallszahl liegt zwischen 1 und 9");
        } else {
            System.out.println("Die Zufallszahl ist 10.");
        }
        // dangling else:
        // Zuordnungsproblem bei zwei if und einem else:
        // Hier gibt es zwei Interpretationsmöglichkeiten:
        // - Variante 1: else zugeordnet zu dem ersten if ?
        //if (true)
        //    if (true)
        //        System.out.println("true");
        //else
        //    System.out.println("false");
        // - Variante 2: else zugeordnet zu dem zweiten if
        //if (true)
        //    if (true)
        //        System.out.println("true");
        //    else
        //    System.out.println("false");
        // Compiler ignoriert Einrückung, orientiert sich am Programmtext: in beiden Fällen der Gleiche!
        // Mehrdeutigkeit nicht zulässig => Regel:
        // else gehört zum textuell letzten freien if im selben Block („freies“ if = noch keinem else zugeordnet)
        // Explizites Klammern schafft Klarheit und vermeidet Fehler
        // Variante 1:
        if (true) {
            if (true)
                System.out.println("true");
        }
        else
            System.out.println("false");

        // Variante 2:
        if (true) {
            if (true)
                System.out.println("true");
            else
                System.out.println("false");
        }

        // switch-case-Anweisung
        // Abwicklung:
        // Ausdruck wird berechnet (nur einmal)
        // Ergebnis wird unter den case-Labeln gesucht
        // Anweisungen im passenden Zweig werden ausgeführt bis eine break-Anweisung erreicht wird
        // default Zweig: steht als letztes, gibt es nur einmal, wird ausgeführt wenn keiner der anderen Zweige passt

        // klassisch:
        a = 1;
        switch(a) {
            case 0: System.out.println("Null"); break;
            case 1: System.out.println("Eins"); break;
            default:
                System.out.println("Default Verhalten wird ausgeführt");
        }
        // Fall through: was passiert wenn wir kein break setzen?
        switch (a) {
            case 1:	 System.out.println("eins");     //kein break – fall through
            case 2:
                System.out.println("zwei");          //kein break – fall through
            case 3:
                System.out.println("drei");          //kein break – fall through
        }

        // Seit Java 14:
        String operation = "add";
        int result = switch (operation) {
            case "add" -> 5 + 3;
            case "subtract" -> 5 - 3;
            case "multiply" -> 5 * 3;
            case "divide" -> 5 / 3;
            default -> 0;
        };

        System.out.println("Ergebnis: " + result);

        // 9. Wiederholungsstrukturen
        // WHILE: while (Bedingung) {
        //    Anweisung(sfolge);
        //}
        // boolean-Ausdruck Bedingung steuert den Ablauf:
        // 1. Bedingung auswerten
        // 2. Falls true:
        //    --- Anweisung(sfolge) ausführen
        //    --- Zurück zu 1.
        //    --- Falls false: Schleife beendet
        int counter = 0;
        while (counter < 10) {
            System.out.println(counter);
            counter = counter + 1; // counter++;
        }

        // DO-Schleife: Die Anweisungsfolge wird auf jeden Fall 1x ausgeführt
        // do {
        //    Anweisung(sfolge);
        // }  while (Bedingung);
        // Arbeitsweise:
        // 1. Anweisung(sfolge) ausführen
        // 2. Bedingung auswerten
        //    --- Falls true: Zurück zu 1.
        //    --- Falls false: Schleife beendet
        int zahl = 0;
        do {
            System.out.println(zahl);
            zahl++;
        } while (zahl < 100);

        // FOR-SCHLEIFE (IntelliJ Kürzel fori)
        int n = 4;
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        System.out.println(sum);
        // fori
        // FOR-Schleife über Array: IntelliJKürzel: itar
        // FOREACH über Array: IntelliJ Kürzel: iter)

        // 10. Operatoren
        //  +, -, *, /, %
        //    >, <, ==, !=, <=
        //    !, &&, ||
        //    ~, ^, >>, &, |  // Bit-Manipulatoren: ~ negiert Bit, & bitweises und, | bitweises oder, ^ bitweises exkl. oder
        //    ++, --, +=, …

        // 11. Inkrement und Dekrement:
        // Präfix - ++a
        a = 1;
        System.out.println(++a);   // a = 2, dann Ausgabe 2
        System.out.println(++a);   // a = 3, dann Ausgabe 3
        System.out.println(a);    //Ausgabe 3
        //Postfix - a++
        a = 1;
        System.out.println(a++);  // Ausgabe 1, dann a = 2
        System.out.println(a++);  // Ausgabe 2, dann a = 3
        System.out.println(a);    // Ausgabe 3

        // 12. Arrays - Felder zum Abspeichern von Variablen primitiven Datentyps oder auch Referenzvariablen/Objekten
        // Arrays erhalten ihre Länge bei der Initialisierung:
        // Die Länge kann danach nicht mehr verändert werden
        int[] arry = new int[5]; // Datentyp-Array arrayName = new Datentyp[anzahlElemente]
        // Indizes starten bei 0 und gehen bis array.length-1
        // Ohne vorher festgelegt zu haben, die Felder des Arrays werden mit default-Werten initialisiert
        for (int i1 = 0; i1 < arry.length; i1++) {
            System.out.println(arry[i1]);
        }
        // wohingegen dies nicht möglich ist:
        int[] barry;
        for (int i1 = 0; i1 < arry.length; i1++) {
            //System.out.println(barry[i1]);
        }

        // Das ist auch eine gültige Array Initialisierung:
        int[] carry = {3,7,1,9};
        for (int i = 0; i < carry.length; i++) {
            System.out.println(carry[i]);
        }

        // In der Vorlesung ebenfalls angesprochen:
        for (int i = 0, j=carry.length; i < carry.length; i++,j--) {
            if (j != i)
                System.out.println("j!=i   " + carry[i]);
        }

        // FOREACH Schleife: der Schleifenzähler repräsentiert das Objekt an einer Feldposition:
        String[] darry = {"ach", "so", "geht", "das","!"};
        for (String i : darry) {
            System.out.println(i);
        }

        // Dies ist ein mehrdimensionales Array:
        char[][] m1 = { {'x','x','x'},
                {'o','o','o'},
                {'x','x','x'}};
        // Hier ist noch ein mehrdimensionales Array:
        char[][] m2 = new char[2][4]; // default Wert für char: '\u0000' - dezimales Äquivalent: 0
        for (int i1=0;i1<m2.length;i1++) {
            for (int i2=0; i2<m2[i1].length;i2++) {
                if (m2[i1][i2] == '\u0000')
                    System.out.print("1 ");
                else
                    System.out.print("0 ");
            }
            System.out.println();
        }

        // 13. Arrays verändern:
        // Wenn man ein double-Array um z.B. 10 Zufallszahlen erweitern möchte das z.B. so:
        double[] garry = {2.1,3.4,6.7};
        double[] newArry = erweitern(garry);
        for (int i = 0; i < newArry.length; i++) {
            System.out.println(newArry[i]);
        }

        // 14. Strings - kein primitiver Datentyp, sondern eine Klasse
        String s1 = "Hallo";
        String s2 = "Griasdi";
        String s3 = s1 + s2;    // Ergebnis: "HalloGriasdi" --- Konkatenation

        // s1/s2/s3 sind Referenzvariablen
        // Der Vergleich Ihrer Identität macht keinen Sinn, denn S1/s2/s3 sind an unterschiedlichen Speicherorten abgelegt.
        if (s1 != s2) {
            System.out.println("s1 und s2 sind nicht gleich!");
        }
        // wenn man auf Inhalt vergleichen will, dann verwendet man die dafür vorgesehene Klassenmethode:
        if (s1.equals(s2)) {
            System.out.println("Der Inhalt von s1 und s2 ist identisch");
        } else
            System.out.println("Der Inhalt von s1 und s2 ist nicht identisch");

        // wohingegegen s1 auf einen String mit Gänsefüsschen verglichen werden kann:
        if (s1 == "Hallo")
            System.out.println("YES!");


        // SCANNER:
        Scanner scanner = new Scanner(System.in);
    }
    // 7. definieren einer Hilfsmethode
    public static int doppelterWert(int a) {
        // Signatur: Sichtbarkeit Rückgabetyp methodenName([Parameterliste bestehend aus Datentyp und Name])
        // Methodennamen: beginnen mit Kleinbuchstaben, jedes weitere Wort wird mit Großbuchstaben daran gehängt - Camelcase!
        // static: Klassenmethode - diese Methoden können aufgerufen werden, ohne von der Klasse erst ein
        // Objekt erzeugt haben zu müssen. Weitere Beispiele: main-Methode, Klasse char oder math (bieten statische Methoden an)
        return a * 2;
    }

    // 13. Hilfsfunktion um double Array um 10 Zufallszahlen zu erweitern
    public static double[] erweitern(double[] arry) {
        double[] arryNew = new double[arry.length+10];

        for (int i = 0; i < arry.length; i++) {
            arryNew[i] = arry[i];
        }
        for (int i = arry.length; i < arryNew.length; i++) {
            arryNew[i] = ((int)(Math.random()*100))/10.0; // >= 0.0 und <1.0
        }
        return arryNew;
    }
}

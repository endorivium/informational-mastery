package kapitel_03_junit.demo_bruch;

public class Bruch {
    private int z,n;
    public Bruch(int z, int n){
        this.z=z;
        this.n=n;
    }
    public Bruch multipliziere(Bruch b){
        return new Bruch(z*b.getZ(),n*b.getN());
    }
    public double getDouble(){ return (double) z/n; }
    public int getZ(){ return z;}
    public int getN() { return n;}
}

package kapitel_03_junit.demo_bruch;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestBruch {
    Bruch[] meineBrueche;
    Double[] meineDoubleErg;


    @BeforeEach
    public void initialisiere(){
        meineBrueche = new Bruch[]{
                new Bruch(1,3),
                new Bruch(2,5)
        };
        meineDoubleErg = new Double[]{
                ((double)1)/3,
                ((double)2)/5
        };
    }
    
    @Test
    public void multipliziere() {
        Bruch soll = new Bruch(2,15);
        Bruch eindrittel= new Bruch(1,3);
        Bruch zweifuenftel = new Bruch(2,5);
        Bruch ist = eindrittel.multipliziere(zweifuenftel);

        //assertEquals("Ich teste ein drittel mal zwei fünftel",soll,ist);
        assertEquals(soll.getZ(),ist.getZ(),"Test Zaehler");
        assertEquals(soll.getN(),ist.getN(),"Test Nenner");
    }

    @Test
    public void getDoubleTest(){
       for(int i=0;i<meineDoubleErg.length;i++){
           assertEquals( meineDoubleErg[i], meineBrueche[i].getDouble(),0);
       }
    }
}
package kapitel_03_junit;

// Zunächst einmal die Framework Imports:
// Diese beiden braucht man eigentlich immer

import kapitel_03_junit.demo_student.Student;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

// Weitere können folgen, z.B. mit ALT+Enter hinzugefügt werden

/**
 * Basis - Template zur Verwendung bei JUnit5 Tests mit IntelliJ.
 * @author Silke Lechner-Greite
 * @version 1.0
 */
public class TestTemplate { // TODO: Benennen Sie die Klasse um, TestName, wobei Name durch den Klassennamen ersetzt wird, worauf sich der Test bezieht.

    Student petra ;

    /**
     * EINMALIGE Vorbereitung
     * @BeforeAll
     */
    @BeforeAll
    @DisplayName("SETUP")
    static void beforeClass() {
        // hier passieren zB Initialisierung, welche für alle Tests gelten
        System.out.println("Initialisiere externe Ressourcen...");
    }


    @AfterAll
    @DisplayName("TEARDOWN")
    static void afterClass() {
        // hier passieren zB Trennungen von Verbindungen
        System.out.println("Trenne externe Ressourcen...");
    }

    /**
     * Vorbereitung für jeden einzelnen Test
     */
    @BeforeEach
    @DisplayName("BeforeEach")
    void setup() {
        // hier passieren zB Objekt-Initialisierungen, welche für alle Tests gelten

        petra = new Student("Petra","WIF");
    }

    /**
     * Nachbereitung für jeden einzelnen Test
     */
    @AfterEach
    @DisplayName("AfterEach")
    void tearDown() {
        // hier de-referenzieren wir alle Objekte wieder
    }


    /**
     * hier folgen die Tests:
     * fügen Sie die Testmethoden ein:
     * Benennen Sie die einzelnen Tests aussagekräftig, z.B.:
     * void testName() {...}
     * wobei sich Name auf den Methodennamen bezieht, die Sie gerade testen.
     * Vergeben Sie Testnamen, durch @DisplayName("Dupolikate"), @DisplayName("Leere Liste"), etc.
     */
    @Test
    void testName1(){
        int a = 100;
        assertTrue(a == 100);
        //assertEquals("Petra", petra.getName());
    }

    @Test
    void testName2() {
        // TODO
    }

    // ...

}

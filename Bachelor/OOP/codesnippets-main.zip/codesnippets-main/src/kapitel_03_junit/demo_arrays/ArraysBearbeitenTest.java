package kapitel_03_junit.demo_arrays;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ArraysBearbeitenTest {

    // dies ist unser erster Test: Reihenfolge
    @Test
    void testMaximumReihenfolge(){
        int[] testArray = {6,7,5};
        assertEquals(7, ArraysBearbeiten.maximum(testArray));
        assertEquals(7, ArraysBearbeiten.maximum(new int[] {7,5,6}));
        assertEquals(7, ArraysBearbeiten.maximum(new int[] {7,6,5}));
        assertEquals(7, ArraysBearbeiten.maximum(new int[] {5,7,6}));
        assertEquals(7, ArraysBearbeiten.maximum(new int[] {6,5,7}));
    }

    @Test
    void testMaximumDoppelteWerte() {
        assertEquals(7,ArraysBearbeiten.maximum(new int[] {5,7,6,7}));
    }

    @Test
    void testMaximumEinstelligesArray() {
        assertEquals(7,ArraysBearbeiten.maximum(new int[] {7}));
    }

    @Test
    void testMaximumNegativ() {

        assertEquals(-5,ArraysBearbeiten.maximum(
                new int[] {-5,-7,-6}));
    }

    @Test
    void testMaximumLeer() {
        try{
            ArraysBearbeiten.maximum(new int[] {});
            fail("Jetzt hätte eine Exception geworfen werden sollen");
        }catch (RuntimeException e){
            System.out.println(e.getCause());
            assertNull(e.getCause());
            System.out.println(e.getMessage());
        }
    }

}

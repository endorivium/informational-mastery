package kapitel_03_junit.demo_arrays;

public class ArraysBearbeiten {
    /**
     * Beispiel Klasse, um statische Methoden zu sammeln, mit denen
     * Arrays durchsucht werden können.
     * @author  	SLG
     * @version     1.0
     */

    /**
     * Finde das größte Element im Array
     * @param arry ein int[]
     * @return größtes int Element des Arrays
     */
    public static int maximum(int[] arry) {
        int maxi = Integer.MIN_VALUE;

        if (arry.length == 0)
            throw new RuntimeException("Leere Liste!");

        for (int i = 0; i < arry.length; i++) {
            if (arry[i] > maxi) {
                maxi = arry[i];
            }
        }
        // Sonst
        return maxi;
    }
}

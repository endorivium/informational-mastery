package vorlesung.kapitel03.DemoStudent;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
// diese Imports kommen im Laufe des Codings hinzu...
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import static java.time.Duration.ofMillis;

/**
 * Testklasse TestStudent zum Testen der Klasse Student.
 *
 * Mehr zum Thema "Run Tests with Coverage":
 * https://www.jetbrains.com/help/idea/running-test-with-coverage.html#
 *
 * @author      SLG
 * @version     1.1, 22.5.2020
 * @since       1.0
 *
 */

public class StudentTest {

    private Student s;

    @BeforeEach
    void setUp(){
        this.s = new Student(); // wir arbeiten mit einem "default" Studenten
        System.out.println("Studentobjekt erzeugt.");
    }

    @AfterEach
    void tearDown(){
        this.s = null;
        System.out.println("Studentobjekt dereferenziert.");
    }

    @Test
    @DisplayName("Besuche Vorlesung")
    void testBesucheVorlesung() {
        assertEquals("motiviert",s.getEmoji());
        // wird das Attribut emoji auf "konzentriert gesetzt?
        s.besucheVorlesung();
        assertEquals("konzentriert",s.getEmoji(),"Der Student konzentriert sich nicht.");
    }

    @Test
    @DisplayName("Test auf - Richtigkeit")
    void testLoeseAufgabeRichtigkeit() {
        double x = s.loeseAufgabe(9);
        assertEquals(4,s.getSchlafdauer());
        assertEquals(3,x,0.1,"Ergebnis falsch berechnet.");
    }

    @Test
    @DisplayName("Test auf - Randbedingungen")
    void testLoeseAufgabeBoundary() {
        double a = Double.NaN;
        double x = s.loeseAufgabe(-1);
        assertEquals(a,x,"Grenzfall: sqrt(-1) - NaN");
    }

    @Test
    @DisplayName("Test auf - Inverser Aufruf")
    void testLoeseAufgabeInverse() {
        double x = s.loeseAufgabe(9);
        assertEquals(9,x*x,0.0001,"Umgekehrte Funktion zu ungenau.");
    }

    @Test
    @DisplayName("Test auf - Vergleich mit alternativem Lösungsansatz")
    void testLoeseAufgabeCrossCheck() {
        int a = 9;
        double x = s.loeseAufgabe(a);
        System.out.println("x:" + x);
        // alternativer Ansatz: Heron-Verfahren (https://de.wikipedia.org/wiki/Heron-Verfahren)
        double x0 = (a+1)/2;
        double x1 = 0.5*(x0+a/x0);
        double x2 = 0.5*(x1+a/x1);
        double x3 = 0.5*(x2+a/x2);
        System.out.println("x3:" + x3);
        assertEquals(x,x3,0.0001,"Umgekehrte Funktion zu ungenau.");
    }

    @Test
    @DisplayName("Schlafen")
        // Dieser Test soll von vorne herein nicht funktionieren
        // wann? wenn die getestete Funktion noch nicht implementiert ist
        // oder ein Verhalten noch nicht korrekt umgesetzt wurde
    void schlafen() {
        fail("Nicht schlafen, aufpasssen ^_^");
    } //Schlafen??? -> fail().

    @Test
    @DisplayName("Löse Schwere Aufgabe - Palindrom")
    void testLoeseSchwereAufgabe() {
        assertTrue(s.loeseSchwereAufgabe("Anna"),"Anna ist wohl ein Palindrom!");
    }

    @Test
    @DisplayName("Schwere Aufgabe in bestimmter Zeit geschafft?")
    void testLoeseSchwereAufgabeTimeOut() {
        assertTimeout(ofMillis(1), () -> {s.loeseSchwereAufgabe("AaaaaaaaaannaaaaaaaaaA");
        });
    }

    @ParameterizedTest
    // JUnit übergibt automatisch jeden String aus @ValueSource als Parameter an die Testmethode
    @ValueSource(strings = {
            "otto",
            "Blaukraut bleibt Blaukraut und Brautkleid bleibt Brautkleid",
            "Risotto, Sir?",
            "Radar",
            "Irgend ein Quatsch",
            "Racecar",
            "Lagerregal",
            "Was it a rat I saw",
            "Madam, I'm Adam",
            "Never odd or even",
    })
        // Intern passiert Folgendes:
        // testLoeseSchwereAufgabeParametrized("otto")
        //testLoeseSchwereAufgabeParametrized("Blaukraut bleibt Blaukraut und Brautkleid bleibt Brautkleid")
        //testLoeseSchwereAufgabeParametrized("Risotto, Sir?")
    void testLoeseSchwereAufgabeParametrized(String palims) {
        assertTrue(s.loeseSchwereAufgabe(palims));
    }
}

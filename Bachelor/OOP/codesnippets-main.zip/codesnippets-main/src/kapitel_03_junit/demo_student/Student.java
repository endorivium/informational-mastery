package vorlesung.kapitel03.DemoStudent;


// Die Klasse Student als Schablone eines Studenten mit einem Auszug an Eigenschaften / Attributen
// und Verhalten / Methoden.


public class Student {

    private String name;
    private String studiengang;
    private String emoji;
    private int schlafdauer;
    private int matrikelnummer;

    private static int studentCounter = 0;

    public Student(){
        this("","");
        System.out.println("Default Konstruktor");
    }

    public Student(String name, String studiengang) {
        this(name,studiengang,"motiviert");         // ruft den parameterlosen Konstruktor auf
        System.out.println("Werte Konstruktor");
    }

    public Student(String name, String studiengang, String emoji) {
        this.name = name;
        this.studiengang = studiengang;
        this.emoji = emoji;
        this.schlafdauer=8;
        studentCounter++;
        this.matrikelnummer = studentCounter;
        System.out.println("Werte Konstruktor 2");
    }

    public void besucheVorlesung(){
        emoji = "konzentriert";
    }

    public double loeseAufgabe(int zahl) {
        schlafdauer -= 4;
        return Math.sqrt(zahl);
    }

    public boolean loeseSchwereAufgabe(String palindrome) {

        // Prüfe, ob String ein Palindrom ist
        // Liest sich von vorne wie von hinten gleich
        // ignoriert Groß-/Kleinschreibung
        // ignoriert alle Nicht-Buchstaben

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < palindrome.length(); i++)
            if (Character.isAlphabetic(palindrome.charAt(i))) // nur alphabetische Zeichen
                sb.append(Character.toLowerCase(palindrome.charAt(i))); // wandle in Kleinbuchstaben um
        palindrome = sb.toString();

        for (int i = 0; i < palindrome.length()/2; i++) { // vergleiche String von außen nach innen
            if (palindrome.charAt(i) != palindrome.charAt(palindrome.length() - 1 - i)){
                return false;}
        }
        return true;
    }

    public void exmatrikuliere(int mnr){
        if (mnr==this.matrikelnummer) {
            System.out.println("Student mit der Matrikelnummer " + this.matrikelnummer + " ist exmatrikuliert.");
            studentCounter--;
            emoji = "geschafft!";
            schlafdauer += 8;
        }
        else
            System.out.println("Es handelt sich hier um den falschen Studenten!");
    }


    // SETTER und GETTER Methoden

    public String getName() {
        return name;
    }
    public String getEmoji() {
        return emoji;
    }
    public int getSchlafdauer() {
        return schlafdauer;
    }
    public void setName(String name) {
        this.name = name;
    }

    /* public static int getStudentCounter() {
        return studentCounter;
    }
    public int getMatrikelNummer() {
        return this.matrikelnummer;
    }
    public String getStudiengang() {
        return studiengang;
    }
    public void setStudiengang(String studiengang) {
        this.studiengang = studiengang;
    }
    public void setEmoji(String emoji) {
        this.emoji = emoji;
    }
    public void setSchlafdauer(int schlafdauer) {
        this.schlafdauer = schlafdauer;
    }
    public void setMatrikelnummer(int matrikelnummer) {
        this.matrikelnummer = matrikelnummer;
    } */

    @Override
    public String toString(){
        return name + ", " + studentCounter + ", " + studiengang;
    }


}




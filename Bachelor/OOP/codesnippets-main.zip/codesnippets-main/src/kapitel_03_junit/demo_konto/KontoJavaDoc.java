package kapitel_03_junit.demo_konto;

/**
 * Die Klasse KontoJavaDoc vom Kapitel2 der Vorlesung OOP
 * soll nun mit Javadoc Kommentaren ausgestattet werden
 * <p>
 * Eine Liste ist auch möglich:
 * <ul>
 *  <li>Inhalt 1
 *  <li>Inhalt 2
 * </ul>
 *
 * @author SLG
 * @author StudentA
 * @version 1.0, 12.5.2020
 * @since 1.0
 * @see <a href="#Student()>Student()</a>
 * @see <a href="Konto#Konto()>Konto()</a>
 *
 *
 */
public class KontoJavaDoc {

    // Objektattribute
    /**
     * Die Kontonummer.
     *
     * @see #getKontoNummer()
     */
    private int kontoNummer;
    // Klassenattribut
    /**
     * Ein Klassenattribut als Zähler.
     */
    private static int zaehler = 0;

    /**
     * Werte-Konstruktor (nur 1 Eingabeparameter)
     *
     * @param k Kontonummer mit der initialisiert wird
     * @author SLG
     * @version 1.1, 12.5.2020
     */
    public KontoJavaDoc(int k) {
        zaehler++;                  // weiteres Kommentieren erlaubt und erwünscht!
        this.kontoNummer = k;
    }

    /**
     * Vergleicht Kontonummer des eigenen Objekts mit der Kontonummer eines anderen Objektes
     * und liefert true oder false zurück.
     *
     * @param other Objekt vom Typ KontoJavaDoc
     * @return boolscher Ausdruck (true - gleich, false - ungleich)
     * @author SLG
     * @version 1.1 12.5.2020
     * @since 1.0
     */
    public boolean compare (KontoJavaDoc other) {
        if (kontoNummer == other.kontoNummer)
            return true;
        else
            return false;
    }

    /**
     * Vertauscht die Kontonummern des eigenen Objektes mit der Kontonummer eines anderen Objektes
     * @param other
     * @author SLG
     * @version 1.1, 12.5.2020
     */
    public void vertauscheKtNr (KontoJavaDoc other) {
        int tmp = other.kontoNummer;
        other.kontoNummer = this.kontoNummer;
        this.kontoNummer = tmp;
    }

    /**
     * Liefert die Kontonummer des eigenen Objektes zurück.
     * @return Kontonummer vom Typ int
     * @author SLG
     * @version 1.0, 12.5.2020
     */
    public int getKontoNummer() {return this.kontoNummer;}

}

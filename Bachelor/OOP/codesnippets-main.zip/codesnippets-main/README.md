# OOP - SoSe2026

In diesem Repo lade ich die Code Snippets der Vorlesung hoch.

```
git clone https://inf-git.th-rosenheim.de/oop-inf/sose26/codesnippets.git
```

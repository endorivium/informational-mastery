#include <Arduino.h>

#pragma GCC push_options
#pragma GCC optimize ("O3")

// PIN configuration
const int BUTTON_PIN = ; //TODO: Specify the digital input according to your wiring

// Global variables
bool flag = ; //TODO: initialise flag

/*!
 * setup() is called once on startup/reset of the Arduino
 */
void setup(){
  //Configure serial connection
  Serial.begin(9600);
  while (!Serial) {
    ; // wait for serial port to connect.
  }

  //configure PINs
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  
  //Configure interrupt
  attachInterrupt(digitalPinToInterrupt(BUTTON_PIN), isr_button_pressed, RISING);
}

/*!
 * loop() is called as fast as possible.
 */
void loop(){
  // Wait until the flag changes (set by ISR)
  Serial.println("Waiting for button press...");

  //TODO: Busy wait until the flag is true
  

  Serial.println("Button pressed! Flag is now set.");
  
  // TODO: Reset flag

}

/*!
 * isr_button_pressed() = Interrupt service routine
 * Change here the state of the flag
 */
void isr_button_pressed(){
  static unsigned long time_prev_rising_edge = 0;
  unsigned long current_time = millis();

  if (current_time - time_prev_rising_edge > 250) { //only react on rising edges every 250 ms
    Serial.println("ISR: Button interrupt");
    //TODO: Set flag

    time_prev_rising_edge = current_time;
  }
}

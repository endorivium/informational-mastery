#include <stdio.h>  //fopen, ...
#include <stdlib.h> //EXIT_SUCCESS
#include <stdint.h> //uint8_t, uint64_t

uint64_t swap_bytes(uint64_t value_to_swap); //prototype

int main(void) {
    uint64_t value = 0;

    FILE* file = NULL;
    file = fopen("../output.txt", "rb");
        
    if (file == NULL) {
        printf("Error opening output.txt\n");
        return EXIT_FAILURE;
    }

    fread(&value, sizeof(uint64_t), 1, file);
    fclose(file);

    printf("Read from output.txt -> : %8lx\n", value);

    //TODO: fix the byte order (you may call the swap_bytes() function for that)


    //TODO: print the fixed value

    
    return EXIT_SUCCESS;
}

uint64_t swap_bytes(uint64_t value_to_swap) {
    union {
        uint64_t value;
        uint8_t byte[8];
    } SWAP_TYPE;

    //TODO: fix the byte order (you may use the union for that)


    return SWAP_TYPE.value;
}

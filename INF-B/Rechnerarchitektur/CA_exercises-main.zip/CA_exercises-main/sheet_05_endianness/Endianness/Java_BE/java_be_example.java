import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

public class java_be_example {

    public static void main(String[] args) throws IOException {
    
        long val = 0x12345678AABBCCDDL;
        byte[] b = ByteBuffer.allocate(8).putLong(val).array();
        
        System.out.println("Value write:");
        System.out.println(String.format("val = %x", val));
        System.out.println(String.format("b[0] = %x", b[0]));
        System.out.println(String.format("b[1] = %x", b[1]));
        System.out.println(String.format("b[2] = %x", b[2]));
        System.out.println(String.format("b[3] = %x", b[3]));
        System.out.println(String.format("b[4] = %x", b[4]));
        System.out.println(String.format("b[5] = %x", b[5]));
        System.out.println(String.format("b[6] = %x", b[6]));
        System.out.println(String.format("b[7] = %x", b[7]));
        System.out.println("");
        
        try(FileOutputStream file = new FileOutputStream("../output.txt")){ // write into output.txt
            System.out.println("Write " + String.format("val = %x", val) + " into output.txt");
            file.write(b);
        } catch(IOException ex) {
            System.out.println("Error while writing output.txt");
        }
    }
}

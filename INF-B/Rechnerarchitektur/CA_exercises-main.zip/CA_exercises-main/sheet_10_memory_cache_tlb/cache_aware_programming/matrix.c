#include <stdio.h>
#include <stdlib.h>

#define WIDTH 2048
#define HEIGHT 2048

int matrix[HEIGHT][WIDTH];

void print_usage(char** argv) {
    printf("Usage: %s <mode>\n", argv[0]);
    printf("  modes:\n");
    printf("    c     column loop mode\n");
    printf("    r     row loop mode\n");
}

void init_matrix() {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            matrix[i][j] = i + j;
        }
    }
}

void print_sum(long long sum) {
    printf("Matrix sum: %lld\n", sum);
}

void column_major_sum() {
    long long sum = 0;
    //TODO: implement sum caluclation by first:
    // - iterate over column, and then
    // - iterate over row


    print_sum(sum);
}

void row_major_sum() {
    long long sum = 0;
    //TODO: implement sum caluclation by first:
    // - iterate over row, and then
    // - iterate over column


    print_sum(sum);
}

int main(int argc, char** argv) {
    if(argc != 2){
        printf("Error: Number of given parameters not supported or no parameter given.\n");
        print_usage(argv);
        exit(EXIT_FAILURE);
    }

    init_matrix();

    switch (argv[1][0])
    {
    case 'c':
        column_major_sum();
        break;
    case 'r':
        row_major_sum();
        break;
    default:
        printf("Error: unknown mode '%c' used\n", argv[1][0]);
        print_usage(argv);
        exit(EXIT_FAILURE);
    }
    
    return 0;
}

# add switch
ovs-vsctl del-port br0 vethARemote
ovs-vsctl del-port br0 vethBRemote
ovs-vsctl del-port br0 vethCRemote
ip netns del hostA
ip netns del hostB
ip netns del hostC
ovs-vsctl del-br br0

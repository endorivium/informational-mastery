# add switch
ovs-vsctl add-br br0

# Host A
sudo ip netns add hostA
ip link add vethA type veth peer name vethARemote
ip link set vethA netns hostA
ip netns exec hostA ip addr add 10.0.0.1/24 dev vethA
ip netns exec hostA ip link set vethA up
ip link set vethARemote up
ovs-vsctl add-port br0 vethARemote

# Host B
ip netns add hostB
ip link add vethB type veth peer name vethBRemote
ip link set vethB netns hostB
ip netns exec hostB ip addr add 10.0.0.2/24 dev vethB
ip netns exec hostB ip link set vethB up
ip link set vethBRemote up
ovs-vsctl add-port br0 vethBRemote

# Host C
ip netns add hostC
ip link add vethC type veth peer name vethCRemote
ip link set vethC netns hostC
ip netns exec hostC ip addr add 10.0.0.3/24 dev vethC
ip netns exec hostC ip link set vethC up
ip link set vethCRemote up
ovs-vsctl add-port br0 vethCRemote

# flush forwarding table

